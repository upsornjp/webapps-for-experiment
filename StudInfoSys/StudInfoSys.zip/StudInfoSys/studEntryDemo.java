/** *****************************************************************
    studEntryDemo.java

        @author Quansheng Xiao & Jeff Offutt

        @version 1.0    (10/06/2001)
        @version 2.0    (January 2009)
         Yanyan Zhu
         Added new fields: JSP, XML, JDBC, AJax, removed CGI

stores student info
********************************************************************* */

package StudInfoSys;

// Import Java Libraries
import java.io.*;
import java.util.*;
import java.lang.*;


/***********************************************************
 * class studEntryDemo: used for storing student's info.
************************************************************/
public class studEntryDemo
{
   private String FName;
   private String LName;
   private String PIN;
   private String EmailAddress;
   private String Phone;
   private String WebSiteURL;
   private String WebSiteURLuser;
   private String WebSiteURLpwd;
   private String Major;
   private String OtherMajor;
   private String LevelHTML;
   private String LevelJava;
   private String LevelJS;
   private String LevelServlets;
   private String LevelJSP;
   private String LevelXML;
   private String LevelJDBC;
   private String LevelAJax;

studEntryDemo (String fname,
           String lname,
           String pin,
           String emailaddress,
           String phone,
           String websiteURL,
           String websiteURLuser,
           String websiteURLpwd,
           String major,
           String othermajor,
           String levelHTML,
           String levelJava,
           String levelJS,
           String levelServlets,
           String levelJSP,
           String levelXML,
           String levelJDBC,
           String levelAJax
           )
{
   FName = fname;
   LName = lname;
   PIN = pin;
   EmailAddress = emailaddress;
   Phone        = phone;
   WebSiteURL   = websiteURL;
   WebSiteURLuser   = websiteURLuser;
   WebSiteURLpwd   = websiteURLpwd;
   Major        = major;
   OtherMajor   = othermajor;
   LevelHTML     = levelHTML;
   LevelJava     = levelJava;
   LevelJS       = levelJS;
   LevelServlets = levelServlets;
   LevelJSP      = levelJSP;
   LevelXML      = levelXML;
   LevelJDBC     = levelJDBC;
   LevelAJax     = levelAJax;
}

public String getFName()
{
   return FName;
}

public String getLName()
{
   return LName;
}

public String getPIN()
{
   return PIN;
}

public String getEmailAddress()
{
   return EmailAddress;
}

public String getPhone()
{
   return Phone;
}

public String getWebSiteURL()
{
   return WebSiteURL;
}

public String getWebSiteURLuser()
{
   return WebSiteURLuser;
}

public String getWebSiteURLpwd()
{
   return WebSiteURLpwd;
}

public String getMajor()
{
   return Major;
}

public String getOtherMajor()
{
   return OtherMajor;
}

public String getLevelHTML()
{
   return LevelHTML;
}

public String getLevelJava()
{
   return LevelJava;
}

public String getLevelJS()
{
   return LevelJS;
}

public String getLevelServlets()
{
   return LevelServlets;
}

public String getLevelJSP()
{
   return LevelJSP;
}

public String getLevelXML()
{
   return LevelXML;
}

public String getLevelJDBC()
{
   return LevelJDBC;
}

public String getLevelAJax()
{
   return LevelAJax;
}
} // end of studEntryDemo class
