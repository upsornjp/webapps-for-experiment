/** *****************************************************************
    studInfoSysDemo.java   SWE 642 Student Information

        @author Quansheng Xiao & Jeff Offutt

        @version 1.0    (10/06/2001)
        @version 1.1    (10/11/2001)
         Removes style sheet usage. Added background color.
         Corrected English mistakes in messages.
         Allow non-numeric PIN.
        @version 1.2    (10/19/2001)
         revised the "Submit New" so that when a new submission
         actually with the same login name and PIN is submitted,
         the data will be carried to the next page.
         This is more convenient for users.
        @version 1.3    (10/25/2001)
         uses XML parser to parse XML file
        @version 1.4    (01/31/2002)
         store majors in a String array
         add test for an empty xml file (add verifyEmptyXMLFile() method)
         add sort-by-lastname function for student info by
         sortByLastName() method
        @version 1.5 (2/6/2002)
         Jeff Offutt
         Update for SWE 642
        @version 1.6 (Jan 2009)
         Jeff Offutt
         Port to CS server
        @version 1.7 (Jan 2009)
         Yanyan Zhu
         Added new fields: JSP, XML, JDBC, AJax, removed CGI
        @version 1.8 (Jun 2014)
         Upsorn P
         Added (username, pwd) for student's URL

Prints a student information form page. After the student inputs
info, aggregates student information and emails to the professor.
The student can retrieve information and update it.

********************************************************************* */
package StudInfoSys;

// Import Servlet Libraries
import javax.servlet.*;
import javax.servlet.http.*;

// Import Java Libraries
import java.io.*;
import java.util.*;
import java.lang.*;

// Import SMTP Class
import sun.net.smtp.SmtpClient;
import org.xml.sax.*;

// studInfoSysDemo class
//
// CONSTRUCTOR: no constructor specified (default)
//
// ****************  OPERATIONS  ****************************************
// void doPost ()  --> Main method for gathering data and sending email.
// void doGet ()   --> Prints the Login Page.
// private void printForm () --> Prints the infomation form.
// private void appendStudInfo () --> Appends info to XML file for new student.
// private String getXML ()--> Puts the parameters into a string buffer as XML.
//                             Returns a string.
// private void writeToFile () --> Saves the information into a XML file.
// private void writePrefixToFile () --> Writes the prefix into the XML file
// private void writePostfixToFile () --> Writes the postfix into the XML file
// public void loadStudList() --> Read students' info from XML file to an Arraylist.
// public static boolean verifyEmptyXMLFile( ) --> Verify if the source XML file is empty.
// private ArrayList sortByLastName() --> Appends info to XML file for new student.
// private boolean verifyStud() --> Checks if the student's info already exists.
// private void updateStudInfo() --> Update student's info to XML file for returned student.
// private void printACK () --> Prints the acknowledgement page.
//***********************************************************************

public class studInfoSysDemo extends HttpServlet
{
//   private static String Servlet = "http://cs.gmu.edu:8080/offutt/servlet/studInfoDemo.studInfoSysDemo"; // CS
   private static String Servlet = "http://cs.gmu.edu:8080/uprapham/servlet/StudInfoSys.studInfoSysDemo"; // CS
   public  static String classWebSiteURL = "http://www.cs.gmu.edu/~offutt/classes/642/";

//   public  static String FileName = "/var/www/CS/webapps/offutt/WEB-INF/data/demo-info.xml"; // CS
   public  static String FileName = "/var/www/CS/webapps/uprapham/WEB-INF/data/stud-info.xml"; // CS
 

   // majors are stored in array majors
   private static String Majors[] = {"SWE", "CS", "ISYS", "IT PhD", "CS PhD", "EE", "ECE", "ISA", "Other"};
//   private static String MAILTO = "offutt@gmu.edu";
   private static String MAILTO = "uprapham@gmu.edu";

   private static String FName;
   private static String LName;
   private static String PIN;
   private static String EmailAddress;
   private static String Phone;
   private static String WebSiteURL;
   private static String WebSiteURLuser;
   private static String WebSiteURLpwd;
   private static String Major;
   private static String OtherMajor;
   private static String LevelHTML;
   private static String LevelJava;
   private static String LevelJS;
   private static String LevelServlets;
   private static String LevelJSP;
   private static String LevelXML;
   private static String LevelJDBC;
   private static String LevelAJax;

   public static ArrayList StudList; // The list of students


/** *****************************************************
 *  Overrides HttpServlet's doGet().
 *  For completeness.
********************************************************* */
public void doGet (HttpServletRequest req, HttpServletResponse res)
   throws ServletException, IOException
{
   res.setContentType ("TEXT/HTML");
   PrintWriter out = res.getWriter ();
   printForm (req, out, "blank", "");

   if (!(new File (FileName).exists()))
   {
      FileWriter datafile = new FileWriter (FileName);
      datafile.close ();
   }

   out.close ();
}
// used as updating flag, if true, update available; if false, update not available
static boolean update = false;

/** *****************************************************
 *  Overrides HttpServlet's doPost().
********************************************************* */
public void doPost (HttpServletRequest req, HttpServletResponse res)
   throws ServletException, IOException
{
   String message;
   res.setContentType ("TEXT/HTML");
   PrintWriter out = res.getWriter ();
   if (!(new File (FileName).exists()))
   {
      FileWriter datafile = new FileWriter (FileName);
      datafile.close ();
   }

   String action = req.getParameter ("submit");
   if (action.equals ("Submit New")) // new student's submission
   {
      FName = req.getParameter ("FName");
      LName = req.getParameter ("LName");
      PIN   = req.getParameter ("PIN");
      if (verifyEmptyXMLFile (FileName) == true)
      {
         loadStudList (FileName);
         if (verifyStud (req, "new") == true)
            printForm (req, out, "login", "A user with the same name already exists or you have already registered your information. "
                   + "<BR> If you want to retrieve your information, press the \"Retrieve\" button.");
         else
         {
            appendStudInfo (req);
            printACK (out, "Your information has been submitted.");
         }
      }
      else
      {
         appendStudInfo (req);
         printACK (out, "Your information has been submitted.");
         // printACK (out, FName, LName, PIN, "Your information has been submitted.");
      }
   }
   else if (action.equals ("Retrieve")) // returned student's retrieve
   {
      update = true;
      FName = req.getParameter ("FName");
      LName = req.getParameter ("LName");
      PIN = req.getParameter ("PIN");
      if (verifyEmptyXMLFile (FileName) == true)
      {
         loadStudList (FileName);
         if (verifyStud (req, "retrieve") == false)
         {
            printForm (req, out, "login", "The combination of the name and PIN is incorrect. Please try again.");
         }
         else
         {
            printForm (req, out, "retrieve", "");
         }
      }
      else
      {
         printForm (req, out, "login", "You are not registered yet. Please use \"Submit New\".");
      }
   }
   else if (action.equals ("Submit Update")) // returned student's submission
   {
      if (verifyEmptyXMLFile (FileName) == false || update == false)
      {
         printForm (req, out, "login", "You are not registered yet. Please use \"Submit New\".");
      }
      else
      {
         loadStudList (FileName);
         // avoids someone making changes to an existing user
         if ( (!(req.getParameter ("FName").equals (FName)) || !(req.getParameter ("LName").equals (LName))
              || !(req.getParameter ("PIN").equals (PIN))) && verifyStud (req, "update") == true )
         {
            printForm (req, out, "login", "A user with the same name already exists. Please try again.");
         }
         else
         {
            update = false;
            updateStudInfo (req);
            printACK (out, "Your information has been updated.");
         }
      }
   }

   out.close ();
} // end of doPost() method


/** *****************************************************
 *  Prints the Information Page.
 *  flag = "blank", prints blank form
 *       = "login", prints form with FName and LName prefilled
 *       = "retrieve", prints form with retrieved data
********************************************************* */
//private void printForm (PrintWriter out, String flag, String errmsg)
   //throws IOExceptionprivate
void printForm (HttpServletRequest req, PrintWriter out, String flag, String errmsg)
      throws ServletException, IOException
{
   out.println ("<HTML>");
   out.println ("");
   out.println ("<HEAD>");
   out.println (" <TITLE>SWE 642 Information Form</TITLE>");
   out.println ("</HEAD>");
   out.println ("");
   out.println ("<BODY BGColor=\"#FFFFFF\">");
   out.println ("");
   out.println ("<SCRIPT LANGUAGE=javascript>");
   out.println ("<!-- hide code");
   out.println ("");

   // submitRetrieve(): JavaScript function, for information intrieve validation
   out.println ("function submitRetrieve (form)");
   out.println ("{");
   out.println ("   errCount=0;");
   out.println ("   errorMsg=\"\";");

   out.println ("   nVal = form.FName.value;");
   out.println ("   if ( nVal == null || nVal == \"\")");
   out.println ("   {");
   out.println ("      errorMsg += \"\\n\\n\"+(errCount+1)+\". Please enter a first name.\";");
   out.println ("      errCount++;");
   out.println ("   }");

   out.println ("   lVal = form.LName.value;");
   out.println ("   if ( lVal == null || lVal == \"\")");
   out.println ("   {");
   out.println ("      errorMsg += \"\\n\\n\"+(errCount+1)+\". Please enter a last name.\";");
   out.println ("      errCount++;");
   out.println ("   }");
   out.println ("");

   out.println ("   PINVal = form.PIN.value;");
   out.println ("   if (PINVal == null || PINVal == \"\" || PINVal.length < 5)");
   out.println ("   {");
   out.println ("      errorMsg += \"\\n\\n\"+(errCount+1)+\". Please enter a 5-digit PIN.\";");
   out.println ("      errCount++;");
   out.println ("   }");
   out.println ("");

   out.println ("   if (errCount > 0)");
   out.println ("   {");
   out.println ("      alert (\"Please correct the following \" + errCount + \" fields\" + errorMsg);");
   out.println ("      return false;");
   out.println ("   }");
   out.println ("   else");
   out.println ("   {");
   out.println ("      <!-- alert(\"Welcome, \" + form.FName.value + \".\") -->");
   out.println ("      return true;");
   out.println ("   }");
   out.println ("} // end function.");
   out.println ("");

   // submitInfo(): JavaScript function, for information submittion validation
   out.println ("function submitInfo (form)");
   out.println ("{");
   out.println ("   errCount=0;");
   out.println ("   errorMsg=\"\";");

   out.println ("   nVal = form.FName.value;");
   out.println ("   if ( nVal == null || nVal == \"\")");
   out.println ("   {");
   out.println ("      errorMsg += \"\\n\\n\"+(errCount+1)+\". Please enter a first name.\";");
   out.println ("      errCount++;");
   out.println ("   }");

   out.println ("   lVal = form.LName.value;");
   out.println ("   if ( lVal == null || lVal == \"\")");
   out.println ("   {");
   out.println ("      errorMsg += \"\\n\\n\"+(errCount+1)+\". Please enter a last name.\";");
   out.println ("      errCount++;");
   out.println ("   }");

   out.println ("   phoneVal=form.Phone.value;");
   out.println ("   if (phoneVal == null || phoneVal == \"\")");
   out.println ("   {");
   out.println ("      errorMsg += \"\\n\\n\"+(errCount+1)+\". Please enter a day-time phone number.\";");
   out.println ("      errCount++;");
   out.println ("   }");

   out.println ("   eMailVal = form.EmailAddress.value;");
   out.println ("   if (eMailVal == null || eMailVal == \"\")");
   out.println ("   {");
   out.println ("      errorMsg += \"\\n\\n\"+(errCount+1)+\". Please enter an email address.\"");
   out.println ("      errCount++;");
   out.println ("   }");

   out.println ("   PINVal = form.PIN.value;");
   out.println ("   if ( PINVal == null || PINVal == \"\" || PINVal.length < 5)");
   out.println ("   {");
   out.println ("      errorMsg += \"\\n\\n\"+(errCount+1)+\". Please enter a 5-digit PIN.\";");
   out.println ("      errCount++;");
   out.println ("   }");
   out.println ("");

   out.println ("   cVal = form.Major.selectedIndex;");
   out.println ("   if ( cVal < 1 ) <!-- was 2 when no default -->");
   out.println ("   {");
   out.println ("      errorMsg += \"\\n\\n\"+(errCount+1)+\". Please enter a major.\"");
   out.println ("      errCount++;");
   out.println ("   }");

   out.println ("   if ( cVal == 9 )");
   out.println ("   {");
   out.println ("      otherMajor = form.OtherMajor.value;");
   out.println ("      if (otherMajor == null || otherMajor == \"\")");
   out.println ("      {");
   out.println ("         errorMsg += \"\\n\\n\"+(errCount+1)+\". \\\"Other\\\" Please enter a major.\"");
   out.println ("         errCount++;");
   out.println ("      }");
   out.println ("   }");
   out.println ("");
   out.println ("   if (errCount > 0)");
   out.println ("   {");
   out.println ("      alert (\"Please correct the following \" + errCount + \" fields\" + errorMsg);");
   out.println ("      return false;");
   out.println ("   }");
   out.println ("   else");
   out.println ("   {");
   out.println ("      <!-- alert(\"Thank you \" + form.FName.value + \" for the information.\") -->");
   out.println ("      return true;");
   out.println ("   }");
   out.println ("} // end function.");
   out.println ("// end hiding code -->");
   out.println ("");
   out.println ("</SCRIPT>");
   out.println ("");
   out.println ("<!-- ------------------------------------------------------- -->");
   out.println ("<!-- End java script checking, start the form. -->");
   out.println ("<!-- ------------------------------------------------------- -->");
   out.println ("");

   //Prints the information form
   out.println ("<DIV Align=\"left\">");
   out.println ("<FORM Method=\"POST\"");
   out.println ("      Action=\""+Servlet+"\" id=form1 name=form1>");
   out.println (" <!-- The following names are sent:");
   out.println ("   Name=\"MAILTO\"");
   out.println ("   Name=\"FName\"");
   out.println ("   Name=\"Major\"");
   out.println ("   Name=\"LName\"");
   out.println ("   Name=\"OtherMajor\"");
   out.println ("   Name=\"EmailAddress\"");
   out.println ("   Name=\"Phone\"");
   out.println ("   Name=\"WebSiteURL\"");
   out.println ("   Name=\"WebSiteURLuser\"");
   out.println ("   Name=\"WebSiteURLpwd\"");
   out.println ("   Name=\"PIN\"");
   out.println ("   Name=\"LevelHTML\"");
   out.println ("   Name=\"LevelJava\"");
   out.println ("   Name=\"LevelJS\"");
   out.println ("   Name=\"LevelServlets\"");
   out.println ("   Name=\"LevelJSP\"");
   out.println ("   Name=\"LevelXML\"");
   out.println ("   Name=\"LevelJDBC\"");
   out.println ("   Name=\"LevelAJax\"");

   out.println (" -->");
   out.println ("");

   out.println ("  <TABLE BORDER=\"0\" CELLPADDING=\"2\" CELLSPACING=\"1\" Width=\"800\">");
   out.println ("   <THEAD>");
   out.println ("    <!-- If we define the widths in the head, we don't need to worry");
   out.println ("         about it in the rest of the table.-->");
   out.println ("    <TR>");
   out.println ("     <TH Width=\"160\">");
   out.println ("     <TH Width=\"160\">");
   out.println ("     <TH Width=\"160\">");
   out.println ("     <TH Width=\"160\">");
   out.println ("     <TH Width=\"160\">");
   out.println ("    </TR>");
   out.println ("   </THEAD>");
   out.println ("");
   out.println ("   <TR>");
   out.println ("    <TD ColSpan=\"5\">");
   out.println ("     <H1 Align=\"center\">SWE 642 - Information Form</H1>");
   out.println ("    </TD>");
   out.println ("   </TR>");
   out.println ("   <TR>");
   out.println ("    <TD ColSpan=\"5\">");
   out.println ("     <H2 Align=\"center\"><U>Design and Implementation of Software for the Web</U></H2>");
   out.println ("    </TD>");
   out.println ("   </TR>");
   out.println ("   <TR><TD ColSpan=\"5\"><HR></TD></TR>");
   out.println ("");

   //display error message
   if (!errmsg.equals (""))
   {
      out.print ("   <TR><TD ColSpan=\"5\"><P style=\"COLOR: red\">" + errmsg);
      out.print ("<BR>If you continue to have trouble, please contact ");
//      out.print ("<A href=\"mailto:" + MAILTO + "\">Dr. Jeff Offutt</A>.");
      out.print ("<A href=\"mailto:" + MAILTO + "\">Upsorn</A>.");
      out.println ("</TD></TR>");
      out.println ("    <TR><TD ColSpan=\"5\"><HR></TD></TR>");
   }

   out.println ("");
   out.println ("   <TR><TD ColSpan=\"5\"><B>Instructions:</B></TD></TR>");
   out.println ("   <TR>");
   out.print ("    <TD ColSpan=\"5\"><U>New students</U>, please fill in all fields ");
   out.print ("and press \"Submit New\" to save your data. ");
   out.print ("The PIN can contain non-numeric characters.");
   out.print ("<BR><U>Returning students</U>, input your first and last name and your PIN, then press \"Retrieve\" to retrieve your old record. ");
   out.println ("Modify your information, then press \"Submit Update\" button to save your new data. ");
   out.println ("    </TD>");
   out.println ("   <TR><TD ColSpan=\"5\"><HR></TD></TR>");
   out.println ("");

   out.println ("    <TR>");
   out.println ("     <TD ColSpan=\"5\" BGColor=\"#333399\">");
   out.println ("      <P Align=\"center\"><FONT Color=\"#FFFFFF\">");
   out.println ("       <B>Please fill in all fields.</B></FONT>");
   out.println ("     </TD>");
   out.println ("    </TR>");
   out.println ("");

   out.println ("    <TR>");
   out.println ("      <TD>First Name</TD>");
   if (flag.equals ("blank"))
      out.println ("      <TD ColSpan=\"2\"><INPUT Type=\"text\" Size=\"20\" Name=\"FName\" ></TD>");
   else if (flag.equals ("login"))
      out.println ("      <TD ColSpan=\"2\"><INPUT Type=\"text\" Name=\"FName\" Value=\"" + req.getParameter ("FName") + "\" size=\"20\"></TD>");
   else if (flag.equals ("retrieve"))
      out.println ("      <TD ColSpan=\"2\"><INPUT Type=\"text\" Size=\"20\" Name=\"FName\" Value=\"" + FName + "\" ></TD>");

   out.println ("      <TD ColSpan=\"2\" >Major&nbsp;&nbsp;");
   out.println ("          <SELECT Name=\"Major\">");
   out.println ("<!--      <OPTION SELECTED Value=\"Select\">Select one</OPTION> -->");
   out.println ("          <OPTION>---------------</OPTION>");
   if (flag.equals ("blank"))
   {
      out.println ("          <OPTION SELECTED Value=\"" + Majors[0] + "\">" + Majors[0] + "</OPTION>");
      for (int i=1; i<Majors.length; i++)
         out.println ("          <OPTION Value=\"" + Majors[i] + "\">" + Majors[i] + "</OPTION>");
   }
   else if (flag.equals ("login"))
   {
      for (int i=0; i<Majors.length; i++)
      {
         if (req.getParameter ("Major").equals (Majors[i]))
            out.println ("          <OPTION SELECTED Value=\"" + Majors[i] + "\">" + Majors[i] + "</OPTION>");
         else
            out.println ("          <OPTION Value=\"" + Majors[i] + "\">" + Majors[i] + "</OPTION>");
      }
   }
   else if (flag.equals ("retrieve"))
   {
      for (int i=0; i<Majors.length; i++)
      {
         if (Major.equals (Majors[i]))
            out.println ("          <OPTION SELECTED Value=\"" + Majors[i] + "\">" + Majors[i] + "</OPTION>");
         else
            out.println ("          <OPTION Value=\"" + Majors[i] + "\">" + Majors[i] + "</OPTION>");
      }
   }
   out.println ("      </SELECT></TD>");
   out.println ("    </TR>");
   out.println ("");

   out.println ("    <TR>");
   out.println ("      <TD>Last Name</TD>");
   if (flag.equals ("blank"))
      out.println ("      <TD ColSpan=\"2\"><INPUT Type=\"text\" Name=\"LName\" size=\"20\"></TD>");
   else if (flag.equals ("login"))
      out.println ("      <TD ColSpan=\"2\"><INPUT Type=\"text\" Name=\"LName\" Value=\"" + req.getParameter ("LName") + "\" size=\"20\"></TD>");
   else if (flag.equals ("retrieve"))
      out.println ("      <TD ColSpan=\"2\"><INPUT Type=\"text\" Size=\"20\" Name=\"LName\" Value=\"" + LName + "\" ></TD>");

   if (flag.equals ("blank"))
      out.println ("      <TD>If other&nbsp;<INPUT Type=\"text\" Name=\"OtherMajor\" size=\"10\"></TD>");
   else if (flag.equals ("login"))
   {
      if (req.getParameter ("Major") == null ||
         (!req.getParameter ("Major").equals ("") &&
          !req.getParameter ("Major").equals ("Other")) )
         out.println ("      <TD>If other&nbsp;<INPUT Type=\"text\" Name=\"OtherMajor\" size=\"10\"></TD>");
      else
         out.println ("      <TD>If other&nbsp;<INPUT Type=\"text\" Name=\"OtherMajor\" Value=\"" + req.getParameter ("OtherMajor") + "\" size=\"10\"></TD>");
   }
   else if (flag.equals ("retrieve"))
   {
      if (Major == null || (!Major.equals ("") && !Major.equals ("Other")) )
         out.println ("      <TD>If other&nbsp;<INPUT Type=\"text\" Name=\"OtherMajor\" size=\"10\"></TD>");
      else
         out.println ("      <TD>If other&nbsp;<INPUT Type=\"text\" Name=\"OtherMajor\" Value=\"" + OtherMajor + "\" size=\"10\"></TD>");
   }
   out.println ("    </TR>");
   out.println ("");

   out.println ("    <TR>");
   out.println ("      <TD>PIN</TD>");
   if (flag.equals ("blank"))
      out.println ("      <TD ColSpan=\"2\"><INPUT Type=\"password\" Name=\"PIN\" size=\"5\" maxLength=\"5\"></TD>");
   else if (flag.equals ("login"))
      out.println ("      <TD ColSpan=\"2\"><INPUT Type=\"password\" Name=\"PIN\" Value=\"" + req.getParameter ("PIN") + "\" size=\"5\" maxLength=\"5\"></TD>");
   else if (flag.equals ("retrieve"))
      out.println ("      <TD ColSpan=\"2\"><INPUT Type=\"password\" Name=\"PIN\" Value=\"" + PIN + "\" size=\"5\" maxLength=\"5\"></TD>");

   out.println ("      <TD ColSpan=\"2\"><I>Please choose a 5-character PIN.</I></TD>");
   out.println ("      <TD></TD>");
   out.println ("    </TR>");
   out.println ("");

   out.println ("    <TR>");
   out.println ("      <TD>Email</TD>");
   if (flag.equals ("blank"))
      out.println ("      <TD ColSpan=\"2\"><TEXTAREA Rows=\"2\" Name=\"EmailAddress\" cols=\"20\"></textarea></TD>");
   else if (flag.equals ("login"))
      out.println ("      <TD ColSpan=\"2\"><TEXTAREA Rows=\"2\" Name=\"EmailAddress\" cols=\"20\">" + req.getParameter ("EmailAddress") + "</textarea></TD>");
   else if (flag.equals ("retrieve"))
      out.println ("      <TD ColSpan=\"2\"><TEXTAREA Rows=\"2\" Name=\"EmailAddress\" cols=\"20\">" + EmailAddress + "</textarea></TD>");

   out.println ("      <TD ColSpan=2><I>Separate multiple EMail IDs by new lines.</I></TD>");
   out.println ("      <TD></TD>");
   out.println ("    </TR>");
   out.println ("");

   out.println ("    <TR>");
   out.println ("      <TD>Day Phone</TD>");
   if (flag.equals ("blank"))
      out.println ("      <TD ColSpan=\"2\"><INPUT Type=\"text\" Name=\"Phone\" size=\"20\"></TD>");
   else if (flag.equals ("login"))
      out.println ("      <TD ColSpan=\"2\"><INPUT Type=\"text\" Name=\"Phone\" Value=\"" + req.getParameter ("Phone") + "\" size=\"20\"></TD>");
   else if (flag.equals ("retrieve"))
      out.println ("      <TD ColSpan=\"2\"><INPUT Type=\"text\" Name=\"Phone\" Value=\"" + Phone + "\" size=\"20\"></TD>");
   out.println ("      <TD></TD>");
   out.println ("      <TD></TD>");
   out.println ("    </TR>");
   out.println ("");

   out.println ("    <TR>");
   out.println ("      <TD>URL</TD>");
   if (flag.equals ("blank"))
      out.println ("      <TD ColSpan=\"2\"><INPUT Type=\"text\" Name=\"WebSiteURL\" size=\"30\" Value=\"http://mason.gmu.edu/\"></TD>");
   else if (flag.equals ("login"))
      out.println ("      <TD ColSpan=\"2\"><INPUT Type=\"text\" Name=\"WebSiteURL\" Value=\"" + req.getParameter ("WebSiteURL") + "\" size=\"20\"></TD>");
   else if (flag.equals ("retrieve"))
      out.println ("      <TD ColSpan=\"2\"><INPUT Type=\"text\" Name=\"WebSiteURL\" Value=\"" + WebSiteURL + "\" size=\"20\"></TD>");
   out.println ("      <TD ColSpan=2><I>Where all of your assignments will be posted.</I></TD>");
   out.println ("      <TD></TD>");
   out.println ("    </TR>");
   out.println ("");

   out.println ("    <TR>");
   out.println ("      <TD>URL (username, password)</TD>");
   if (flag.equals ("blank"))
   {
      out.println ("      <TD ColSpan=\"2\"><INPUT Type=\"text\" Name=\"WebSiteURLuser\" size=\"20\" Value=\"username\"></TD>");
      out.println ("      <TD ColSpan=\"2\"><INPUT Type=\"text\" Name=\"WebSiteURLpwd\" size=\"20\" Value=\"password\"></TD>");
   }
   else if (flag.equals ("login"))
   {
      out.println ("      <TD ColSpan=\"2\"><INPUT Type=\"text\" Name=\"WebSiteURLuser\" Value=\"" + req.getParameter ("WebSiteURLuser") + "\" size=\"20\"></TD>");
      out.println ("      <TD ColSpan=\"2\"><INPUT Type=\"text\" Name=\"WebSiteURLpwd\" Value=\"" + req.getParameter ("WebSiteURLpwd") + "\" size=\"20\"></TD>");
   }
   else if (flag.equals ("retrieve"))
   {
      out.println ("      <TD ColSpan=\"2\"><INPUT Type=\"text\" Name=\"WebSiteURLuser\" Value=\"" + WebSiteURLuser + "\" size=\"20\"></TD>");
      out.println ("      <TD ColSpan=\"2\"><INPUT Type=\"text\" Name=\"WebSiteURLpwd\" Value=\"" + WebSiteURLpwd + "\" size=\"20\"></TD>");
   }
   out.println ("      <TD></TD>");
   out.println ("    </TR>");
   out.println ("");

   out.println ("    <TR>");
   out.println ("    <TD ColSpan=\"5\"><HR></TD>");
   out.println ("    </TR>");
   out.println ("");

   out.println ("    <TR>");
   out.println ("     <TD ColSpan=\"5\" >");
   out.println ("      <P Align=\"center\">");
   out.println ("       <B>Make your best, honest estimate of your knowlege of each of these technologies.</B></FONT>");
   out.println ("     </TD>");
   out.println ("    </TR>");
   out.println ("");

   out.println ("    <TR BGColor=\"#333399\">");
   out.println ("      <TD><FONT Color=\"#FFFFFF\"><B>Topic</B></FONT></TD>");
   out.println ("      <TD Align=\"center\"><FONT Color=\"#FFFFFF\"><B>None</B></FONT></TD>");
   out.println ("      <TD Align=\"center\"><FONT Color=\"#FFFFFF\"><B>Beginner</B></FONT></TD>");
   out.println ("      <TD Align=\"center\"><FONT Color=\"#FFFFFF\"><B>Intermediate</B></FONT></TD>");
   out.println ("      <TD Align=\"center\"><FONT Color=\"#FFFFFF\"><B>Expert</B></FONT></TD>");
   out.println ("    </TR>");
   out.println ("");

   out.println ("    <TR BGcolor=\"#CCDDEE\">");
   out.println ("      <TD>HTML</TD>");
   if (flag.equals ("blank") || flag.equals ("retrieve"))
   {
      if (LevelHTML == null || LevelHTML.equals ("none"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"none\" Checked Name=\"LevelHTML\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"none\" Name=\"LevelHTML\"></TD>");
      if (LevelHTML != null && LevelHTML.equals ("beginner"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"beginner\" Checked Name=\"LevelHTML\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"beginner\" Name=\"LevelHTML\"></TD>");
      if (LevelHTML != null && LevelHTML.equals ("inter"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"inter\" Checked Name=\"LevelHTML\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"inter\" Name=\"LevelHTML\"></TD>");
      if (LevelHTML != null && LevelHTML.equals ("expert"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"expert\" Checked Name=\"LevelHTML\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"expert\" Name=\"LevelHTML\"></TD>");
   }
   else if (flag.equals ("login"))
   {
      if (req.getParameter ("LevelHTML") == null || req.getParameter ("LevelHTML").equals ("none"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"none\" Checked Name=\"LevelHTML\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"none\" Name=\"LevelHTML\"></TD>");
      if (req.getParameter ("LevelHTML") != null && req.getParameter ("LevelHTML").equals ("beginner"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"beginner\" Checked Name=\"LevelHTML\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"beginner\" Name=\"LevelHTML\"></TD>");
      if (req.getParameter ("LevelHTML") != null && req.getParameter ("LevelHTML").equals ("inter"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"inter\" Checked Name=\"LevelHTML\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"inter\" Name=\"LevelHTML\"></TD>");
      if (req.getParameter ("LevelHTML") != null && req.getParameter ("LevelHTML").equals ("expert"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"expert\" Checked Name=\"LevelHTML\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"expert\" Name=\"LevelHTML\"></TD>");
   }
   out.println ("    </TR>");
   out.println ("");

   out.println ("    <TR BGcolor=\"#BBDDFF\">");
   out.println ("      <TD>Java</TD>");

   if (flag.equals ("blank") || flag.equals ("retrieve"))
   {
      if (LevelJava == null || LevelJava.equals ("none"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"none\" Checked Name=\"LevelJava\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"none\" Name=\"LevelJava\"></TD>");
      if (LevelJava != null && LevelJava.equals ("beginner"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"beginner\" Checked Name=\"LevelJava\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"beginner\" Name=\"LevelJava\"></TD>");
      if (LevelJava != null && LevelJava.equals ("inter"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"inter\" Checked Name=\"LevelJava\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"inter\" Name=\"LevelJava\"></TD>");
      if (LevelJava != null && LevelJava.equals ("expert"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"expert\" Checked Name=\"LevelJava\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"expert\" Name=\"LevelJava\"></TD>");
   }
   else if (flag.equals ("login"))
   {
      if (req.getParameter ("LevelJava") == null || req.getParameter ("LevelJava").equals ("none"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"none\" Checked Name=\"LevelJava\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"none\" Name=\"LevelJava\"></TD>");
      if (req.getParameter ("LevelJava") != null && req.getParameter ("LevelJava").equals ("beginner"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"beginner\" Checked Name=\"LevelJava\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"beginner\" Name=\"LevelJava\"></TD>");
      if (req.getParameter ("LevelJava") != null && req.getParameter ("LevelJava").equals ("inter"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"inter\" Checked Name=\"LevelJava\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"inter\" Name=\"LevelJava\"></TD>");
      if (req.getParameter ("LevelJava") != null && req.getParameter ("LevelJava").equals ("expert"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"expert\" Checked Name=\"LevelJava\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"expert\" Name=\"LevelJava\"></TD>");
   }
   out.println ("    </TR>");
   out.println ("");


   out.println ("    <TR BGcolor=\"#CCDDEE\">");
   out.println ("      <TD>JavaScript</TD>");

   if (flag.equals ("blank") || flag.equals ("retrieve"))
   {
      if (LevelJS == null || LevelJS.equals ("none"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"none\" Checked Name=\"LevelJS\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"none\" Name=\"LevelJS\"></TD>");
      if (LevelJS != null && LevelJS.equals ("beginner"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"beginner\" Checked Name=\"LevelJS\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"beginner\" Name=\"LevelJS\"></TD>");
      if (LevelJS != null && LevelJS.equals ("inter"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"inter\" Checked Name=\"LevelJS\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"inter\" Name=\"LevelJS\"></TD>");
      if (LevelJS != null && LevelJS.equals ("expert"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"expert\" Checked Name=\"LevelJS\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"expert\" Name=\"LevelJS\"></TD>");
   }
   else if (flag.equals ("login"))
   {
      if (req.getParameter ("LevelJS") == null || req.getParameter ("LevelJS").equals ("none"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"none\" Checked Name=\"LevelJS\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"none\" Name=\"LevelJS\"></TD>");
      if (req.getParameter ("LevelJS") != null && req.getParameter ("LevelJS").equals ("beginner"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"beginner\" Checked Name=\"LevelJS\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"beginner\" Name=\"LevelJS\"></TD>");
      if (req.getParameter ("LevelJS") != null && req.getParameter ("LevelJS").equals ("inter"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"inter\" Checked Name=\"LevelJS\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"inter\" Name=\"LevelJS\"></TD>");
      if (req.getParameter ("LevelJS") != null && req.getParameter ("LevelJS").equals ("expert"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"expert\" Checked Name=\"LevelJS\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"expert\" Name=\"LevelJS\"></TD>");
   }
   out.println ("    </TR>");
   out.println ("");

   out.println ("    <TR BGcolor=\"#BBDDFF\">");
   out.println ("      <TD>Servlets</TD>");
   if (flag.equals ("blank") || flag.equals ("retrieve"))
   {
      if (LevelServlets == null || LevelServlets.equals ("none"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"none\" Checked Name=\"LevelServlets\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"none\" Name=\"LevelServlets\"></TD>");
      if (LevelServlets != null && LevelServlets.equals ("beginner"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"beginner\" Checked Name=\"LevelServlets\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"beginner\" Name=\"LevelServlets\"></TD>");
      if (LevelServlets != null && LevelServlets.equals ("inter"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"inter\" Checked Name=\"LevelServlets\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"inter\" Name=\"LevelServlets\"></TD>");
      if (LevelServlets != null && LevelServlets.equals ("expert"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"expert\" Checked Name=\"LevelServlets\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"expert\" Name=\"LevelServlets\"></TD>");
   }
   else if (flag.equals ("login"))
   {
      if (req.getParameter ("LevelServlets") == null || req.getParameter ("LevelServlets").equals ("none"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"none\" Checked Name=\"LevelServlets\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"none\" Name=\"LevelServlets\"></TD>");
      if (req.getParameter ("LevelServlets") != null && req.getParameter ("LevelServlets").equals ("beginner"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"beginner\" Checked Name=\"LevelServlets\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"beginner\" Name=\"LevelServlets\"></TD>");
      if (req.getParameter ("LevelServlets") != null && req.getParameter ("LevelServlets").equals ("inter"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"inter\" Checked Name=\"LevelServlets\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"inter\" Name=\"LevelServlets\"></TD>");
      if (req.getParameter ("LevelServlets") != null && req.getParameter ("LevelServlets").equals ("expert"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"expert\" Checked Name=\"LevelServlets\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"expert\" Name=\"LevelServlets\"></TD>");
   }
   out.println ("    </TR>");
   out.println ("");

   out.println ("    <TR BGcolor=\"#CCDDEE\">");
   out.println ("      <TD>JSP</TD>");
   if (flag.equals ("blank") || flag.equals ("retrieve"))
   {
      if (LevelJSP == null || LevelJSP.equals ("none"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"none\" Checked Name=\"LevelJSP\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"none\" Name=\"LevelJSP\"></TD>");
      if (LevelJSP != null && LevelJSP.equals ("beginner"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"beginner\" Checked Name=\"LevelJSP\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"beginner\" Name=\"LevelJSP\"></TD>");
      if (LevelJSP != null && LevelJSP.equals ("inter"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"inter\" Checked Name=\"LevelJSP\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"inter\" Name=\"LevelJSP\"></TD>");
      if (LevelJSP != null && LevelJSP.equals ("expert"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"expert\" Checked Name=\"LevelJSP\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"expert\" Name=\"LevelJSP\"></TD>");
   }
   else if (flag.equals ("login"))
   {
      if (req.getParameter ("LevelJSP") == null || req.getParameter ("LevelJSP").equals ("none"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"none\" Checked Name=\"LevelJSP\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"none\" Name=\"LevelJSP\"></TD>");
      if (req.getParameter ("LevelJSP") != null && req.getParameter ("LevelJSP").equals ("beginner"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"beginner\" Checked Name=\"LevelJSP\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"beginner\" Name=\"LevelJSP\"></TD>");
      if (req.getParameter ("LevelJSP") != null && req.getParameter ("LevelJSP").equals ("inter"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"inter\" Checked Name=\"LevelJSP\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"inter\" Name=\"LevelJSP\"></TD>");
      if (req.getParameter ("LevelJSP") != null && req.getParameter ("LevelJSP").equals ("expert"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"expert\" Checked Name=\"LevelJSP\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"expert\" Name=\"LevelJSP\"></TD>");
   }
   out.println ("    </TR>");
   out.println ("");

   out.println ("    <TR BGcolor=\"#BBDDFF\">");
   out.println ("      <TD>XML</TD>");
   if (flag.equals ("blank") || flag.equals ("retrieve"))
   {
      if (LevelXML == null || LevelXML.equals ("none"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"none\" Checked Name=\"LevelXML\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"none\" Name=\"LevelXML\"></TD>");
      if (LevelXML != null && LevelXML.equals ("beginner"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"beginner\" Checked Name=\"LevelXML\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"beginner\" Name=\"LevelXML\"></TD>");
      if (LevelXML != null && LevelXML.equals ("inter"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"inter\" Checked Name=\"LevelXML\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"inter\" Name=\"LevelXML\"></TD>");
      if (LevelXML != null && LevelXML.equals ("expert"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"expert\" Checked Name=\"LevelXML\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"expert\" Name=\"LevelXML\"></TD>");
   }
   else if (flag.equals ("login"))
   {
      if (req.getParameter ("LevelXML") == null || req.getParameter ("LevelXML").equals ("none"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"none\" Checked Name=\"LevelXML\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"none\" Name=\"LevelXML\"></TD>");
      if (req.getParameter ("LevelXML") != null && req.getParameter ("LevelXML").equals ("beginner"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"beginner\" Checked Name=\"LevelXML\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"beginner\" Name=\"LevelXML\"></TD>");
      if (req.getParameter ("LevelXML") != null && req.getParameter ("LevelXML").equals ("inter"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"inter\" Checked Name=\"LevelXML\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"inter\" Name=\"LevelXML\"></TD>");
      if (req.getParameter ("LevelXML") != null && req.getParameter ("LevelXML").equals ("expert"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"expert\" Checked Name=\"LevelXML\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"expert\" Name=\"LevelXML\"></TD>");
   }
   out.println ("    </TR>");
   out.println ("");

   out.println ("    <TR BGcolor=\"#CCDDEE\">");
   out.println ("      <TD>JDBC</TD>");
   if (flag.equals ("blank") || flag.equals ("retrieve"))
   {
      if (LevelJDBC == null || LevelJDBC.equals ("none"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"none\" Checked Name=\"LevelJDBC\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"none\" Name=\"LevelJDBC\"></TD>");
      if (LevelJDBC != null && LevelJDBC.equals ("beginner"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"beginner\" Checked Name=\"LevelJDBC\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"beginner\" Name=\"LevelJDBC\"></TD>");
      if (LevelJDBC != null && LevelJDBC.equals ("inter"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"inter\" Checked Name=\"LevelJDBC\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"inter\" Name=\"LevelJDBC\"></TD>");
      if (LevelJDBC != null && LevelJDBC.equals ("expert"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"expert\" Checked Name=\"LevelJDBC\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"expert\" Name=\"LevelJDBC\"></TD>");
   }
   else if (flag.equals ("login"))
   {
      if (req.getParameter ("LevelJDBC") == null || req.getParameter ("LevelJDBC").equals ("none"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"none\" Checked Name=\"LevelJDBC\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"none\" Name=\"LevelJDBC\"></TD>");
      if (req.getParameter ("LevelJDBC") != null && req.getParameter ("LevelJDBC").equals ("beginner"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"beginner\" Checked Name=\"LevelJDBC\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"beginner\" Name=\"LevelJDBC\"></TD>");
      if (req.getParameter ("LevelJDBC") != null && req.getParameter ("LevelJDBC").equals ("inter"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"inter\" Checked Name=\"LevelJDBC\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"inter\" Name=\"LevelJDBC\"></TD>");
      if (req.getParameter ("LevelJDBC") != null && req.getParameter ("LevelJDBC").equals ("expert"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"expert\" Checked Name=\"LevelJDBC\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"expert\" Name=\"LevelJDBC\"></TD>");
   }
   out.println ("    </TR>");
   out.println ("");

   out.println ("    <TR BGcolor=\"#BBDDFF\">");
   out.println ("      <TD>AJax</TD>");
   if (flag.equals ("blank") || flag.equals ("retrieve"))
   {
      if (LevelAJax == null || LevelAJax.equals ("none"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"none\" Checked Name=\"LevelAJax\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"none\" Name=\"LevelAJax\"></TD>");
      if (LevelAJax != null && LevelAJax.equals ("beginner"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"beginner\" Checked Name=\"LevelAJax\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"beginner\" Name=\"LevelAJax\"></TD>");
      if (LevelAJax != null && LevelAJax.equals ("inter"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"inter\" Checked Name=\"LevelAJax\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"inter\" Name=\"LevelAJax\"></TD>");
      if (LevelAJax != null && LevelAJax.equals ("expert"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"expert\" Checked Name=\"LevelAJax\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"expert\" Name=\"LevelAJax\"></TD>");
   }
   else if (flag.equals ("login"))
   {
      if (req.getParameter ("LevelAJax") == null || req.getParameter ("LevelAJax").equals ("none"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"none\" Checked Name=\"LevelAJax\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"none\" Name=\"LevelAJax\"></TD>");
      if (req.getParameter ("LevelAJax") != null && req.getParameter ("LevelAJax").equals ("beginner"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"beginner\" Checked Name=\"LevelAJax\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"beginner\" Name=\"LevelAJax\"></TD>");
      if (req.getParameter ("LevelAJax") != null && req.getParameter ("LevelAJax").equals ("inter"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"inter\" Checked Name=\"LevelAJax\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"inter\" Name=\"LevelAJax\"></TD>");
      if (req.getParameter ("LevelAJax") != null && req.getParameter ("LevelAJax").equals ("expert"))
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"expert\" Checked Name=\"LevelAJax\"></TD>");
      else
         out.println ("      <TD Align=\"center\"><INPUT Type=\"radio\" Value=\"expert\" Name=\"LevelAJax\"></TD>");
   }
   out.println ("    </TR>");
   out.println ("");


   out.println ("    <TR><TD>&nbsp;</TD></TR> <!-- extra space -->");
   out.println ("");

   out.println ("    <TR>");
   out.println ("      <TD ColSpan=\"5\">");
   out.println ("       &nbsp;&nbsp;");
   out.println ("       <INPUT Type=\"submit\" Value=\"Submit New\" Name=\"submit\" onClick=\"return submitInfo (this.form)\">");
   out.println ("       &nbsp;&nbsp;&nbsp;&nbsp;");
   out.println ("       <INPUT Type=\"submit\" Value=\"Retrieve\" Name=\"submit\" onClick=\"return submitRetrieve (this.form)\">");
   out.println ("       &nbsp;&nbsp;&nbsp;&nbsp;");
   out.println ("       <INPUT Type=\"submit\" Value=\"Submit Update\" Name=\"submit\" onClick=\"return submitInfo (this.form)\">");
   out.println ("       &nbsp;&nbsp;&nbsp;&nbsp;");
   out.println ("       <input Type=\"reset\" Value=\"Reset\" Name=\"reset\" >"); 
   out.println ("      </TD>");
   out.println ("    </TR>");

   out.println ("");
   out.println ("  </TABLE>");
   out.println ("</FORM>");
   out.println ("</DIV>");
   out.println ("");
   out.println ("<HR>");
   out.println ("");

   out.println ("</BODY>");
   out.println ("");
   out.println ("</HTML>");
} // end of method printForm()

/** *****************************************************
 *  Sorts the array by last  name.
********************************************************* */
private ArrayList sortByLastName (ArrayList sl)
{
   int n = sl.size();
   String tmp;
   String f[]= new String [n];
   String l[]= new String [n];
   String pin[]= new String [n];
   String email[]= new String [n];
   String ph[]= new String [n];
   String url[]= new String [n];
   String urluser[]= new String [n];
   String urlpwd[]= new String [n];
   String m[]= new String [n];
   String om[]= new String [n];
   String lhtml[]= new String [n];
   String ljava[]= new String [n];
   String ljs[]= new String [n];
   String ls[]= new String [n];
   String ljsp[]= new String [n];
   String lxml[]= new String [n];
   String ljdbc[]= new String [n];
   String lajax[]= new String [n];

   for (int i = 0; i < n; i++)
   {
      studEntryDemo stud = (studEntryDemo) sl.get (i);
      f[i] = stud.getFName();
      l[i] = stud.getLName();
      pin[i] = stud.getPIN();
      email[i] = stud.getEmailAddress();
      ph[i] = stud.getPhone();
      url[i] = stud.getWebSiteURL();
      urluser[i] = stud.getWebSiteURLuser();
      urlpwd[i] = stud.getWebSiteURLpwd();
      m[i] = stud.getMajor();
      om[i] = stud.getOtherMajor();
      lhtml[i] = stud.getLevelHTML();
      ljava[i] = stud.getLevelJava();
      ljs[i] = stud.getLevelJS();
      ls[i] = stud.getLevelServlets();
      ljsp[i] = stud.getLevelJSP();
      lxml[i] = stud.getLevelXML();
      ljdbc[i] = stud.getLevelJDBC();
      lajax[i] = stud.getLevelAJax();
   }

   //sort by last name
   for (int i = 0; i < n-1; i++)
      for (int j = i+1; j < n; j++)
      {
         if (l[i].compareTo (l[j]) > 0)
         {
            tmp = l[i]; l[i]= l[j]; l[j]= tmp;
            tmp = f[i]; f[i]= f[j]; f[j]= tmp;
            tmp = pin[i]; pin[i]= pin[j]; pin[j]= tmp;
            tmp = email[i]; email[i]= email[j]; email[j]= tmp;
            tmp = ph[i]; ph[i]= ph[j]; ph[j]= tmp;
            tmp = url[i]; url[i]= url[j]; url[j]= tmp;
            tmp = urluser[i]; urluser[i]= urluser[j]; urluser[j]= tmp;
            tmp = urlpwd[i]; urlpwd[i]= urlpwd[j]; urlpwd[j]= tmp;
            tmp = m[i]; m[i]= m[j]; m[j]= tmp;
            tmp = om[i]; om[i]= om[j]; om[j]= tmp;
            tmp = lhtml[i]; lhtml[i]= lhtml[j]; lhtml[j]= tmp;
            tmp = ljava[i]; ljava[i]= ljava[j]; ljava[j]= tmp;
            tmp = ljs[i]; ljs[i]= ljs[j]; ljs[j]= tmp;
            tmp = ls[i]; ls[i]= ls[j]; ls[j]= tmp;
            tmp = ljsp[i]; ljsp[i]= ljsp[j]; ljsp[j]= tmp;
            tmp = lxml[i]; lxml[i]= lxml[j]; lxml[j]= tmp;
            tmp = ljdbc[i]; ljdbc[i]= ljdbc[j]; ljdbc[j]= tmp;
            tmp = lajax[i]; lajax[i]= lajax[j]; lajax[j]= tmp;
         }
      }
   ArrayList sl_tmp = new ArrayList(); // temperary list of students
   for (int i = 0; i < n; i++ )
   {
      sl_tmp.add (new studEntryDemo (f[i], l[i], pin[i], email[i], ph[i], url[i], urluser[i], urlpwd[i], m[i], om[i], lhtml[i], ljava[i], ljs[i], ls[i], ljsp[i], lxml[i], ljdbc[i], lajax[i]));
   }
   return sl_tmp;
} // end of method sortByLastName()

/** *****************************************************
 * Removes a less than character '<' from a string
 * XML does not like them. (It crashes tomcat.)
********************************************************* */
private String trimLT (String s)
{
   if (s.indexOf ('<') >= 0)
   {  // Found one.
      return (s.replace ('<', '#'));
   }
   else
      return s;
}

/** *****************************************************
 *  Appends info to XML file for new student.
********************************************************* */
private void appendStudInfo (HttpServletRequest req)
   throws ServletException, IOException
{
   writePrefixToFile (FileName);

   //if StudList has not been initialized, do it here
   if (StudList == null)
   {
      StudList = new ArrayList();
   }

   FName        = trimLT (req.getParameter ("FName"));
   LName        = trimLT (req.getParameter ("LName"));
   PIN          = trimLT (req.getParameter ("PIN"));
   EmailAddress = trimLT (req.getParameter ("EmailAddress"));
   Phone        = trimLT (req.getParameter ("Phone"));
   WebSiteURL   = trimLT (req.getParameter ("WebSiteURL"));
   WebSiteURLuser   = trimLT (req.getParameter ("WebSiteURLuser"));
   WebSiteURLpwd   = trimLT (req.getParameter ("WebSiteURLpwd"));
   Major        = trimLT (req.getParameter ("Major"));
   if (Major.equals ("Other"))
      OtherMajor = trimLT (req.getParameter ("OtherMajor"));
   else
      OtherMajor = "";
   LevelHTML     = req.getParameter ("LevelHTML");
   LevelJava     = req.getParameter ("LevelJava");
   LevelJS       = req.getParameter ("LevelJS");
   LevelServlets = req.getParameter ("LevelServlets");
   LevelJSP      = req.getParameter ("LevelJSP");
   LevelXML       = req.getParameter ("LevelXML");
   LevelJDBC      = req.getParameter ("LevelJDBC");
   LevelAJax       = req.getParameter ("LevelAJax");


   StudList.add (new studEntryDemo (FName, LName, PIN, EmailAddress, Phone, WebSiteURL, WebSiteURLuser, WebSiteURLpwd,
      Major, OtherMajor, LevelHTML, LevelJava, LevelJS, LevelServlets, LevelJSP, LevelXML, LevelJDBC, LevelAJax));
   StudList = sortByLastName (StudList);
   for (int i = 0; i < StudList.size(); i++ )
   {
      studEntryDemo stud = (studEntryDemo) StudList.get (i);
      FName          = stud.getFName();
      LName          = stud.getLName();
      PIN            = stud.getPIN();
      EmailAddress   = stud.getEmailAddress();
      Phone          = stud.getPhone();
      WebSiteURL     = stud.getWebSiteURL();
      WebSiteURLuser     = stud.getWebSiteURLuser();
      WebSiteURLpwd     = stud.getWebSiteURLpwd();
      Major          = stud.getMajor();
      OtherMajor     = stud.getOtherMajor();
      LevelHTML      = stud.getLevelHTML();
      LevelJava      = stud.getLevelJava();
      LevelJS        = stud.getLevelJS();
      LevelServlets  = stud.getLevelServlets();
      LevelJSP        = stud.getLevelJSP();
      LevelXML        = stud.getLevelXML();
      LevelJDBC        = stud.getLevelJDBC();
      LevelAJax       = stud.getLevelAJax();


      String message = getXML();
      writeToFile (FileName, message);
   }
   writePostfixToFile (FileName);
} // end of method appendStudInfo()

/** *****************************************************
 *  Verify if the source XML file is empty.
 *  if empty, returns false, else returns true.
********************************************************* */
public static boolean verifyEmptyXMLFile (String fileName) throws IOException, FileNotFoundException
{
   BufferedReader fin = new BufferedReader (new FileReader (fileName));
   String s;

   try
   {
      while ((s = fin.readLine() ) != null)
      {
         s = s.trim();
         if (!s.equals (""))
            return true;
      }
   }
   catch (IOException e)
   {
      System.out.println ("File error: " + fileName);
   }
   fin.close();

   //StudList = null; //reset StudList for empty file case
   StudList = new ArrayList();

   return false;
} // end of method verifyEmptyXMLFile()

/** *****************************************************
 *  Read students' info from XML file to an Arraylist.
********************************************************* */
public static void loadStudList (String fileName) throws IOException
{
   try
   {
      parserXMLDemo xp = new parserXMLDemo();
      xp.parse (xp.readFile (fileName));
      StudList = xp.StudList;
   }
   catch (Exception e)
   {
      System.out.println ("Exception: " + e);
      System.out.println ("XML SAXParse error in XMLParser.readDoc()");
   }
} // end of method loadStudInfo()

/* ======================================================== */
static int existIndex; //store the student's index in StudList.
/* ======================================================== */

/** *****************************************************
 *  checks if the student's info already exists.
********************************************************* */
private boolean verifyStud (HttpServletRequest req, String newOrUpdate)
   throws ServletException, IOException
{
   if (newOrUpdate.equals ("new"))
   {
      for (int i = 0; i < StudList.size(); i++ )
      {
         studEntryDemo stud = (studEntryDemo) StudList.get (i);
         if (stud.getFName().equals (FName) && stud.getLName().equals (LName))
         {
            return true;
         }
      }
   }

   else if (newOrUpdate.equals ("retrieve"))
   {
      for (int i = 0; i < StudList.size(); i++ )
      {
         studEntryDemo stud = (studEntryDemo) StudList.get (i);
         if (stud.getFName().equals (FName) &&
             stud.getLName().equals (LName) &&
             stud.getPIN().equals (PIN))
         {
            EmailAddress  = stud.getEmailAddress();
            Phone         = stud.getPhone();
            WebSiteURL    = stud.getWebSiteURL();
            WebSiteURLuser    = stud.getWebSiteURLuser();
            WebSiteURLpwd    = stud.getWebSiteURLpwd();
            Major         = stud.getMajor();
            OtherMajor    = stud.getOtherMajor();
            LevelHTML     = stud.getLevelHTML();
            LevelJava     = stud.getLevelJava();
            LevelJS       = stud.getLevelJS();
            LevelServlets = stud.getLevelServlets();
            LevelJSP       = stud.getLevelJSP();
            LevelXML       = stud.getLevelXML();
            LevelJDBC       = stud.getLevelJDBC();
            LevelAJax       = stud.getLevelAJax();

            existIndex    = i;
            return true;
         }
      }
   }

   else if (newOrUpdate.equals ("update"))
   {
      for (int i = 0; i < StudList.size(); i++ )
      {
         studEntryDemo stud = (studEntryDemo) StudList.get (i);
         if (stud.getFName().equals (req.getParameter ("FName"))
            && stud.getLName().equals (req.getParameter ("LName"))
            && stud.getPIN().equals (req.getParameter ("PIN")))
         {
            return true;
         }
      }
   }

   return false;
} // end of verifyStud() method


/** *****************************************************
 *  Update student's info to XML file for returned student.
********************************************************* */
private void updateStudInfo (HttpServletRequest req) throws ServletException, IOException
{
   FName        = trimLT (req.getParameter ("FName"));
   LName        = trimLT (req.getParameter ("LName"));
   PIN          = trimLT (req.getParameter ("PIN"));
   EmailAddress = trimLT (req.getParameter ("EmailAddress"));
   Phone        = trimLT (req.getParameter ("Phone"));
   WebSiteURL   = trimLT (req.getParameter ("WebSiteURL"));
   WebSiteURLuser   = trimLT (req.getParameter ("WebSiteURLuser"));
   WebSiteURLpwd   = trimLT (req.getParameter ("WebSiteURLpwd"));
   Major        = trimLT (req.getParameter ("Major"));
   OtherMajor   = trimLT (req.getParameter ("OtherMajor"));
   LevelHTML     = req.getParameter ("LevelHTML");
   LevelJava     = req.getParameter ("LevelJava");
   LevelJS       = req.getParameter ("LevelJS");
   LevelServlets = req.getParameter ("LevelServlets");
   
   LevelJSP = req.getParameter ("LevelJSP");
   LevelXML = req.getParameter ("LevelXML");
   LevelJDBC = req.getParameter ("LevelJDBC");
   LevelAJax = req.getParameter ("LevelAJax");

   //replace the element at index existIndex
   StudList.set (existIndex, new studEntryDemo (FName, LName, PIN, EmailAddress, Phone, WebSiteURL, WebSiteURLuser, WebSiteURLpwd,
                Major, OtherMajor, LevelHTML, LevelJava, LevelJS, LevelServlets, LevelJSP, LevelXML, LevelJDBC, LevelAJax));
   StudList = sortByLastName (StudList);
   writePrefixToFile (FileName);
   for (int i = 0; i < StudList.size(); i++ )
   {
      studEntryDemo stud = (studEntryDemo) StudList.get (i);

      //this part is replaced by using StudList.set (index, (Object)element)
/*
      if (i == existIndex)
      {
         FName = req.getParameter ("FName");
         LName = req.getParameter ("LName");
         PIN = req.getParameter ("PIN");
         EmailAddress = req.getParameter ("EmailAddress");
         Phone = req.getParameter ("Phone");
         WebSiteURL = req.getParameter ("WebSiteURL");
         Major = req.getParameter ("Major");
         OtherMajor = req.getParameter ("OtherMajor");
         LevelHTML = req.getParameter ("LevelHTML");
         LevelJava = req.getParameter ("LevelJava");
         LevelCGI = req.getParameter ("LevelCGI");
         LevelJS = req.getParameter ("LevelJS");
         LevelServlets = req.getParameter ("LevelServlets");
      }
      else
*/
      {
         FName = stud.getFName();
         LName = stud.getLName();
         PIN = stud.getPIN();
         EmailAddress = stud.getEmailAddress();
         Phone = stud.getPhone();
         WebSiteURL = stud.getWebSiteURL();
         WebSiteURLuser = stud.getWebSiteURLuser();
         WebSiteURLpwd = stud.getWebSiteURLpwd();
         Major = stud.getMajor();
         OtherMajor = stud.getOtherMajor();
         LevelHTML = stud.getLevelHTML();
         LevelJava = stud.getLevelJava();
         LevelJS = stud.getLevelJS();
         LevelServlets = stud.getLevelServlets();
         LevelJSP = stud.getLevelJSP();
         LevelXML = stud.getLevelXML();
         LevelJDBC = stud.getLevelJDBC();
         LevelAJax = stud.getLevelAJax();
      }

      String message = getXML();
      writeToFile (FileName, message);
   }
   writePostfixToFile (FileName);

} // end of method saveStudInfo()


/** *****************************************************
 *  Puts the parameters into a string buffer as XML.
 *  Returns a string.
********************************************************* */
private String getXML() throws IOException
{
   StringBuffer tempStringBuffer = new StringBuffer (4096);

   tempStringBuffer.append ("  <StudentInfo>\n");
   // Format the contact info.
   tempStringBuffer.append ("    <FName>");
   tempStringBuffer.append (FName);
   tempStringBuffer.append ("</FName>\n");
   tempStringBuffer.append ("    <LName>");
   tempStringBuffer.append (LName);
   tempStringBuffer.append ("</LName>\n");
   tempStringBuffer.append ("    <PIN>");
   tempStringBuffer.append (PIN);
   tempStringBuffer.append ("</PIN>\n");

   // Handle several email addresses, separated by a carriage
   // return and line feed.
   // Loop through the email address looking for the next
   // carriage return, stop when there is none.
   int ret = EmailAddress.indexOf ('\r'); // Return
   while (ret != -1) // handle several email addresses
   {
      String curemail = EmailAddress.substring (0, ret);
      tempStringBuffer.append ("    <EmailAddress>");
      tempStringBuffer.append (curemail);
      tempStringBuffer.append ("</EmailAddress>\n");
      EmailAddress = EmailAddress.substring (ret+2, EmailAddress.length());
      ret = EmailAddress.indexOf ('\r'); // Return
   }
   tempStringBuffer.append ("    <EmailAddress>");
   tempStringBuffer.append (EmailAddress);
   tempStringBuffer.append ("</EmailAddress>\n");

   tempStringBuffer.append ("    <URL>");
   tempStringBuffer.append (WebSiteURL);
   tempStringBuffer.append ("</URL>\n");
   tempStringBuffer.append ("    <URLuser>");
   tempStringBuffer.append (WebSiteURLuser);
   tempStringBuffer.append ("</URLuser>\n");
   tempStringBuffer.append ("    <URLpwd>");
   tempStringBuffer.append (WebSiteURLpwd);
   tempStringBuffer.append ("</URLpwd>\n");
   
   tempStringBuffer.append ("    <Phone>");
   tempStringBuffer.append (Phone);
   tempStringBuffer.append ("</Phone>\n");
   tempStringBuffer.append ("    <Major>");
   tempStringBuffer.append (Major);
   tempStringBuffer.append ("</Major>\n");
   tempStringBuffer.append ("    <OtherMajor>");
   tempStringBuffer.append (OtherMajor);
   tempStringBuffer.append ("</OtherMajor>\n");

   // Now print the levels of knowledge of the various subjects.
   tempStringBuffer.append ("    <LevelHTML>");
   tempStringBuffer.append (LevelHTML);
   tempStringBuffer.append ("</LevelHTML>\n");
   tempStringBuffer.append ("    <LevelJava>");
   tempStringBuffer.append (LevelJava);
   tempStringBuffer.append ("</LevelJava>\n");
   tempStringBuffer.append ("    <LevelJS>");
   tempStringBuffer.append (LevelJS);
   tempStringBuffer.append ("</LevelJS>\n");
   tempStringBuffer.append ("    <LevelServlets>");
   tempStringBuffer.append (LevelServlets);
   tempStringBuffer.append ("</LevelServlets>\n");
   tempStringBuffer.append ("    <LevelJSP>");
   tempStringBuffer.append (LevelJSP);
   tempStringBuffer.append ("</LevelJSP>\n");
   tempStringBuffer.append ("    <LevelXML>");
   tempStringBuffer.append (LevelXML);
   tempStringBuffer.append ("</LevelXML>\n");
   tempStringBuffer.append ("    <LevelJDBC>");
   tempStringBuffer.append (LevelJDBC);
   tempStringBuffer.append ("</LevelJDBC>\n");
   tempStringBuffer.append ("    <LevelAJax>");
   tempStringBuffer.append (LevelAJax);
   tempStringBuffer.append ("</LevelAJax>\n");
   tempStringBuffer.append ("  </StudentInfo>\n");

   return (tempStringBuffer.toString());
} // end of getXML() emthod

/** *****************************************************
 *  Writes the Prefix into the XML file
********************************************************* */
private void writePrefixToFile (String fileName)
{
   try
   {
      FileWriter datafile = new FileWriter (fileName);
      datafile.write ("<ClassSWEDemo>\n");
      datafile.write ("\n");
      datafile.close ();
   }
   catch (IOException e)
   {
      log ("Error occurred while writing to file", e);
   }
}

/** *****************************************************
 *  Writes the Postfix into the XML file
********************************************************* */
private void writePostfixToFile (String fileName)
{
   try
   {
      FileWriter datafile = new FileWriter (fileName, true);
      datafile.write ("</ClassSWEDemo>");
      datafile.close ();
   }
   catch (IOException e)
   {
      log ("Error occurred while writing to file", e);
   }
}

/** *****************************************************
 *  Saves the information into a file
********************************************************* */
private void writeToFile (String fileName, String Mes)
{
   try
   {
      FileWriter datafile = new FileWriter (fileName, true);
      datafile.write (Mes);
      datafile.write ("\n");
      datafile.close ();
   }
   catch (IOException e)
   {
      log ("Error occurred while writing to file", e);
   }
}

/** *****************************************************
 *  Prints the acknowledgement page.
********************************************************* */
private void printACK (PrintWriter out, String message)
   throws IOException
{
   out.println ("<HTML>");
   out.println ("<HEAD>");
   out.println (" <TITLE>642 Student Information Acknowledgement</TITLE>");
   out.println ("</HEAD>");

   out.println ("<BODY BGColor=\"#FFFFF\">");
   out.println ("<CENTER><H2>642 Student Information Acknowledgement</H2></CENTER>");
   out.println ("<HR>");
   // Send ack
   out.println ("<BR>" + message + "<BR>");

// Sometimes this printed the PREVIOUS info, I don't know why. Jeff Offutt, January 2009
// out.println ("<BR>Remember your name and PIN in case you need to update this information later:");
// out.println ("<BR>&ndash;&nbsp;" + FName);
// out.println ("<BR>&ndash;&nbsp;" + LName);
// out.println ("<BR>&ndash;&nbsp;" + PIN + "<BR>");

   out.println ("<BR>Thank you!<BR><BR>");
   out.println ("<A HREF=\"" + classWebSiteURL + "\">Class web site</A>");
   out.println ("<BR><A HREF=\"" + Servlet + "\">Student information system form</A>");

   out.println ("</BODY>");
   out.println ("</HTML>");
   out.close ();
}
} // end of StudinfoSysDemo class
