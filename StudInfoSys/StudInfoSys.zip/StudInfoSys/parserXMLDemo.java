/** *****************************************************************
    parserXMLDemo.java

        @author Quansheng Xiao & Jeff Offutt

        @version 1.0    (10/25/2001)
        @version 2.0    (January 2009)
         Yanyan Zhu
         Added new fields: JSP, XML, JDBC, AJax, removed CGI

  parses a XML file
********************************************************************* */
package StudInfoSys;

import java.io.*;
import java.util.*;

import org.w3c.dom.*;
import org.xml.sax.*;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;

// parserXMLDemo class
//
// ****************  OPERATIONS  ************************************************
// void parserXMLDemo ()  --> default constructor
// public static Document readFile() --> converts a filename to a uri for parsing
// public static Document readDoc() --> creates a DOM object
// public void parse() --> parses a xml file
// public void parseRec() --> parses throught a file
// public void parseChildren() --> recursively parses through a file
//*******************************************************************************

public class parserXMLDemo
{
/*
  public static void main (String argv[]) throws Exception {
    if (argv.length != 1) {
      System.out.println ("usage: java studInfoDemo.parserXMLDemo xmlFile");
      System.exit(1);
    }
    parserXMLDemo dmW = new parserXMLDemo();
    dmW.parse (dmW.readFile (argv[0]));

System.out.println ("StudList length: " + dmW.StudList.size());
  }
*/

//Constructor
public parserXMLDemo()
{
}


//converts a filename to a uri for parsing
public Document readFile (String fileName) throws Exception
{
  if (null == fileName)
  {
    throw new Exception ("no fileName for readFile()");
  }
  String uri = "file:" + new File (fileName).getAbsolutePath();
  return readDoc (uri);
}


//creates a DOM object
public Document readDoc (String uri) throws Exception
{
  Document doc;
  try {// create a DOM object using JAXP abstract classes
    DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
    DocumentBuilder db = dbf.newDocumentBuilder();
    doc = db.parse (uri);
    return doc;
  } catch (SAXParseException ex) {
    //throw (ex);
    System.out.println ("SAXParseException: " + ex);
    System.out.println ("SAXParse error in XMLParser.readDoc (" + uri + ")");
    return null;
  } catch (SAXException ex) {// do some logging
    //throw (ex);
    System.out.println ("SAXException: " + ex);
    System.out.println ("SAXParse error in XMLParser.readDoc (" + uri + ")");
    return null;
  }
}


// stores the students' info after parsing the XML file
public ArrayList StudList;// = new ArrayList();

private static String f="", l="", pin="", email="", ph="", url="", urluser="", urlpwd="", m="";
private static String om="", lhtml="", ljava="", ljs="", ls="";
private static String ljsp="", lxml="", ljdbc="", lajax="";
private static boolean recordStart = false;
private static StringBuffer e = new StringBuffer (1024);
private static String previousNodeName = "";


// parses an XML file
public void parse (Node node) throws IOException, SAXException
{
  if (node == null)
  {
    System.out.println ("SAXParse error from XML file.");
    System.exit(0);
  }
  else
  {
    //reset variables, critical important
    StudList = new ArrayList();
    recordStart = false;
    previousNodeName = "";
    e.setLength(0);

    parseRec (node);

    //handles the last student's info
    email = e.toString();
    StudList.add (new studEntryDemo (f, l, pin, email, ph, url, urluser, urlpwd, m, om, lhtml, ljava, ljs, ls, ljsp, lxml, ljdbc, lajax));
  }
} // end of parse()


//parses throught a file
public void parseRec (Node node) throws IOException, SAXException
{
  short nodeType = node.getNodeType();

  if (nodeType == Node.ELEMENT_NODE) {
    String nodeName = node.getNodeName();
    previousNodeName = nodeName;

    if (nodeName.equals ("StudentInfo"))
    {
       if (recordStart == false)
       {
          recordStart = true;
       }
       else
       {
          email = e.toString();
          StudList.add (new studEntryDemo (f, l, pin, email, ph, url, urluser, urlpwd, m, om, lhtml, ljava, ljs, ls,ljsp, lxml, ljdbc, lajax));
          e.setLength(0); //reset e
       }
    }
    parseChildren (node);
  }

  else if (nodeType == Node.TEXT_NODE)
  {
    //if (recordStart == true)
    {
      if (previousNodeName.equals ("FName"))
        f = node.getNodeValue().trim();
      else if (previousNodeName.equals ("LName"))
        l = node.getNodeValue().trim();
      else if (previousNodeName.equals ("PIN"))
        pin = node.getNodeValue().trim();
      else if (previousNodeName.equals ("Phone"))
        ph = node.getNodeValue().trim();
      else if (previousNodeName.equals ("URL"))
        url = node.getNodeValue().trim();
      else if (previousNodeName.equals ("URLuser"))
        urluser = node.getNodeValue().trim();
      else if (previousNodeName.equals ("URLpwd"))
        urlpwd = node.getNodeValue().trim();
      else if (previousNodeName.equals ("Major"))
        m = node.getNodeValue().trim();
      else if (previousNodeName.equals ("OtherMajor"))
        om = node.getNodeValue().trim();
      else if (previousNodeName.equals ("LevelHTML"))
        lhtml = node.getNodeValue().trim();
      else if (previousNodeName.equals ("LevelJava"))
        ljava = node.getNodeValue().trim();
      else if (previousNodeName.equals ("LevelJS"))
        ljs = node.getNodeValue().trim();
      else if (previousNodeName.equals ("LevelServlets"))
        ls = node.getNodeValue().trim();
      else if (previousNodeName.equals ("LevelJSP"))
        ljsp = node.getNodeValue().trim();
      else if (previousNodeName.equals ("LevelXML"))
        lxml = node.getNodeValue().trim();
      else if (previousNodeName.equals ("LevelJDBC"))
        ljdbc = node.getNodeValue().trim();
      else if (previousNodeName.equals ("LevelAJax"))
        lajax = node.getNodeValue().trim();
      else if (previousNodeName.equals ("EmailAddress"))
      {
        if( e.length() != 0 ) // if multiple email addresses, use new lines to separate
          e.append ("\r\n");
        e.append (node.getNodeValue().trim());
      }
      previousNodeName = "";//reset to empty
    }
  }

  else if (nodeType == Node.DOCUMENT_NODE)
  {
    parseChildren (node);
  }

  else {
    //does nothing
  }
}// end of parseRec()


//recursively parses through a file
public void parseChildren (Node node) throws IOException, SAXException
{
  NodeList children = node.getChildNodes();
  for (int i = 0; i < children.getLength(); i++)
  {
    parseRec (children.item (i));
  }
}

}  // End Parser XML
