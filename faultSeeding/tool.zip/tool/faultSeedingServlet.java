/** *****************************************************************
    faultSeedingServlet.java     
        @author Upsorn Praphamontripong
        @version 1.0    (06/14/2014)
        
    note: 05/27/2014: current version of faultSeedingServlet supports only java servlet (can't check/compile jsp yet)
          06/01/2014: (known bug, not fixed yet) if the file to seed faults contains a <textarea> tag, 
                      faultSeedingServlet must properly parse and display the code. 
                      One solution is to use StringEscapeUtils.escapeHtml4 
********************************************************************* */


package tool;

import java.io.*;
import java.util.*;

import javax.tools.*;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FileUtils;

import tool.util.DirFileFilter;
import tool.util.ExtensionFilter;

/**
 * Servlet implementation class faultSeedingServlet
 */
@WebServlet("/faultSeedingServlet")
public class faultSeedingServlet extends HttpServlet 
{
   private static final long serialVersionUID = 1L;

//**** setting for local  ****/   
   private static String LoginServlet = "http://localhost:8080/experiment/tool.login";       
   private static String LogoutServlet = "http://localhost:8080/experiment/tool.logout";  
   protected final static String SERVLET_PATH ="http://localhost:8080/experiment/tool.faultSeeder";
   
   protected static String SRC_DIR = "/Applications/apache-tomcat-7.0.54/webapps/experiment/WEB-INF/data/faultseeding_src"; // folder where original source files are stored  
   protected static String ASSIGNED_DIR = SRC_DIR;
   protected final static String RESULT_DIR = "/Applications/apache-tomcat-7.0.54/webapps/experiment/WEB-INF/faultseeding_result"; // folder where faulty files and faulty classes will be stored

   protected static String clienthintjsLocation = "http://localhost:8080/experiment/tool/clienthint.js";  
   protected static String wztooltipjsLocation = "http://localhost:8080/experiment/tool/wz_tooltip.js";  
   
   private String selectedFile = new String();   
   private String infilename;                 // input filename
   private String outfilename;                // output filename    
   private String org_str;                    // string from original file
   private String edited_str;                 // string edited to be recorded as faulty version of program 
   private String msg;                        // whether compilation error or successful (along w/ faulty filename generated) 
   private String detail_error_msg;           
   private String action; 
   
   private String foldername;                 // filename without suffix
   private String suffix;                     // .java, .jsp, .html   
   private String user;                   
 
   private int error_cnt = 0;
	
  /**
   * @see HttpServlet#HttpServlet()
   */
   public faultSeedingServlet() 
   {
      super();       
   }

   
  /**
   * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
   */
   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
   {	  
      response.setContentType("text/html");
      PrintWriter out = response.getWriter();
      PrintHead(out);	         

      HttpSession session = request.getSession(true);
      user = (String)session.getAttribute("UserID");
      
      // if the faultSeedingServlet is accessed without logging in, 
      // redirect to login servlet
      if (user == null || user.length() == 0)
      { 
    	 resetAllVariables();
         response.sendRedirect (LoginServlet);
      }
      else
      {
    	 msg = (String)session.getAttribute("msg");
    	 detail_error_msg = (String)session.getAttribute("detailErrorMsg");
    	 selectedFile = (String)session.getAttribute("selectedFile");

    	 // update ASSIGNED_DIR, a folder assigned to a particular participant
         // i.e., contains a list of subjects specifically assigned to this participant
         ASSIGNED_DIR = SRC_DIR + "/" + user;

         org_str = "";      // string from original file 
         edited_str = "";   // string edited to be recorded as faulty version of program
         
         int line_no = 0;
         if (selectedFile != null && selectedFile.length() >0)
         {
        	org_str = "";
        	edited_str = "";
        	if ( ((String)session.getAttribute("compileError")).equals("Yes") )
        	{
        	   edited_str = (String)session.getAttribute("errorCode");
        	   msg = (String)session.getAttribute("msg");
        	   detail_error_msg = (String)session.getAttribute("detailErrorMsg");
        	   action = (String)session.getAttribute("action");
        	}
        	
        	infilename = ASSIGNED_DIR + "/" + selectedFile;
        	
            // if an existing fault is retrieved, display the corresponding code in txtfaultyCode 
            if ( ((String)session.getAttribute("action")).equals("Retrieve") )
           	   infilename = (String)session.getAttribute("faultyFile");
        	
            try 
            {
               File file = new File(infilename);
               FileReader fileReader = new FileReader(file);               
               BufferedReader bufferedReader = new BufferedReader(fileReader);
               String text = new String();
               while ( (text = bufferedReader.readLine()) != null)
               {
            	  line_no++;
            	  if (org_str != null && org_str.length() > 0)
                     org_str = org_str + line_no + " : " + text + "\n";
            	  else 
            		 org_str = line_no + " : " + text + "\n";
                  
                  if ( ((String)session.getAttribute("compileError")).equals("No"))         
                  {
                	 if (edited_str != null && edited_str.length() > 0)
                        edited_str = edited_str + line_no + " : " + text + "\n";
                	 else 
                		edited_str = line_no + " : " + text + "\n";
                	 
                     msg = (String)session.getAttribute("msg");
                     detail_error_msg = (String)session.getAttribute("detailErrorMsg");
                  }
               }
               bufferedReader.close();
            } catch (Exception e)
            {
               // Should also display error message on screen/browser
               System.out.println("Error in doGet(), read input file: " + e);	
            }
         }
         
         if ( ((String)session.getAttribute("action")).equals("Reset") )
        	edited_str = org_str; 
        	        	 
		 PrintBody(out, org_str, edited_str);
	     out.println("</html>");	  			   
	     out.close();    
      }
   }

	
   /**
    * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
    */
   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
   {
      //////////////////////////////////////////////////////////// 
      // For each file of a subject web app, 
	  // prepare folder's name and faulty's filename  
	  // i.e., subjectapp/corresponding faulty versions 
	  // 
	  // check the edited source code (txtFaultyCode) to ensure compilable
	  // and write to file (faulty version)
	  ////////////////////////////////////////////////////////////	   
	   
      response.setContentType("text/html");
      PrintWriter out = response.getWriter ();	  
      
      HttpSession session = request.getSession();
      user = (String)session.getAttribute("UserID");
      
      String button = request.getParameter("btn");
      if (button.equals("Open") || button.equals("Clear")) 
      {
    	 selectedFile = request.getParameter("targetfile");
    	 session.setAttribute("compileError", "No");
    	 session.setAttribute("errorCode", "");
    	 session.setAttribute("msg", "");
    	 session.setAttribute("detailErrorMsg", "");
    	 session.setAttribute("faultyFile", "");
    	 session.setAttribute("orgCode", "");
    	 if (button.equals("Open"))
    	 {
    	    session.setAttribute("action", "Open");
    	    session.setAttribute("selectedFile", selectedFile);
    	    session.setAttribute("msg", "Open selected file");
    	 }
    	 if (button.equals("Clear"))
    	 {
    		session.setAttribute("selectedFile", "");
    		session.setAttribute("action", "Clear");
    	 }
      }
      else if (button.equals("Reset"))
      {
    	 session.setAttribute("compileError", "No");
    	 session.setAttribute("errorCode", "");
    	 session.setAttribute("msg", "Reset screen");
    	 session.setAttribute("detailErrorMsg", "");
    	 session.setAttribute("selectedFile", selectedFile);
    	 session.setAttribute("faultyFile", "");
    	 session.setAttribute("orgCode", org_str);    	 
    	 session.setAttribute("action", "Reset");
      }
      else if (button.equals("Retrieve"))
      {
     	 String retrievedFile = selectedFile; 
     	 int i = retrievedFile.lastIndexOf("/");
     	 if (i > 0)    
     		retrievedFile = request.getParameter("listFault") + "/" + retrievedFile.substring(i+1, retrievedFile.length());
     	 else
     		retrievedFile = request.getParameter("listFault") + "/" + retrievedFile; 
     	 
         String temp_str = "/faultseeding_result/" + user + "/";
         String fault_id = retrievedFile;
         if (fault_id != null & fault_id.length() > 0)
         {
            int n = fault_id.indexOf(temp_str);
            if ( (n > 0) && ((n+temp_str.length()) < fault_id.length()) )
           	fault_id = fault_id.substring( (n + temp_str.length()), fault_id.length());
         }

     	 File file = new File(retrievedFile);
         if (!file.exists())
    	    session.setAttribute ("msg", ("[Errors] " + fault_id + " -- Faulty version does not exist. Cannot retrieve.") );
         else 
        	session.setAttribute("msg", "");
     	 
    	 session.setAttribute("compileError", "No");
    	 session.setAttribute("errorCode", "");
    	 session.setAttribute("detailErrorMsg", "");
    	 session.setAttribute("selectedFile", selectedFile);
    	 session.setAttribute("faultyFile", retrievedFile);
    	 session.setAttribute("orgCode", "");
    	 session.setAttribute("action", "Retrieve");
      }
      else if (button.equals("Delete"))
      {
    	 String retrievedFile = (String)session.getAttribute("faultyFile");
    	 if (retrievedFile != null && retrievedFile.length() > 0)
    	 {
            String temp_str = "/faultseeding_result/" + user + "/";
            String fault_id = retrievedFile;
            if (fault_id != null & fault_id.length() > 0)
            {
               int n = fault_id.indexOf(temp_str);
               if ( (n > 0) && ((n+temp_str.length()) < fault_id.length()) )
              	fault_id = fault_id.substring( (n + temp_str.length()), fault_id.length());
            }
    		 
     	    try
     	    {
               File file = new File(retrievedFile);
               File faultyfile = new File(file.getParent());
               if (!faultyfile.exists())
               {
         		  session.setAttribute ("compileError", "No");
         		  session.setAttribute ("errorCode", "");
         		  session.setAttribute ("msg", ("[Errors] " + fault_id + " -- Faulty version does not exist. Cannot deleted") );
         		  session.setAttribute ("detailErrorMsg", "");
         		  session.setAttribute ("selectedFile", selectedFile);
         		  session.setAttribute ("faultyFile", retrievedFile);
         		  session.setAttribute ("orgCode", org_str);
         		  session.setAttribute ("action", "Delete");
               }
               else 
               {  
                  String log_filename = new String();
                  int i = (faultyfile.getAbsolutePath()).lastIndexOf("_");
                  if (i > 0)
                  {
                     log_filename = (faultyfile.getAbsolutePath()).substring(0, i) + "_log.txt";
                     String log_str = faultyfile.getAbsolutePath() + ":Deleted-on-" + (new Date()).getTime();  
                     String updatelog_status = updateLog(log_filename, log_str, "Delete");
                     FileUtils.deleteDirectory(faultyfile);
           		     session.setAttribute ("msg", (fault_id + "-- Faulty version deleted"));
                  }
                  else
             		 session.setAttribute ("msg", ("[Errors] " + fault_id + " -- Cannot retrieve/update log file.") );

        		  session.setAttribute ("compileError", "No");
        		  session.setAttribute ("errorCode", "");
        		  session.setAttribute ("detailErrorMsg", "");
        		  session.setAttribute ("selectedFile", selectedFile);
        		  session.setAttribute ("faultyFile", retrievedFile);
        		  session.setAttribute ("orgCode", org_str);
        		  session.setAttribute ("action", "Delete");
               }  
     	    } catch (Exception e)
            {   System.out.println("Problem delete existing faulty file : " + e.toString());  }
    	 }
    	 else
    		session.setAttribute ("msg","[Errors] Cannot retrieve a faulty version.");         
      }
      else if (button.equals("Generate") || button.equals("Update"))
      {
         // check if a faulty code (tempfile) is compilable
    	 // prepare output filename and write faulty code to output file (actual faulty file)
         // e.g., output filename /WEB-INF/faultseeding_result/username/stis/browse/browse_2.jsp 
    	 // indicates 2nd fault version generated for a subject stis/browse.jsp
    	  
    	 // if a faulty code cannot be compiled, prompt error messages to the user
    	 // no file is generated
    	 
    	 error_cnt = 0;   // reset number of errors for the current selected file
    	 
    	 edited_str = request.getParameter("txtFaultyCode");    //  string to be written to file
         foldername = RESULT_DIR + "/" + user ;                
		 
         String faultyFilename = selectedFile;
         
         // extract faultyFilename, prepare proper faulty folder and outfilename 
         suffix = "";
         outfilename = faultyFilename;
         String rootFolder = new String();
         String subFolder = new String();
         
         int n = faultyFilename.indexOf(".java");
         if (n > 0)     suffix = ".java";
         else 
         {
            n = faultyFilename.indexOf(".jsp");
            if (n > 0)    suffix = ".jsp";
         }
          
         n = faultyFilename.indexOf("/");
         if (n > 0)
         {
            outfilename = faultyFilename.substring(n+1, faultyFilename.length());
            subFolder = faultyFilename.substring(0, n);
            rootFolder =  ASSIGNED_DIR + "/" + faultyFilename.substring(0, n);  // e,g., stis or webstutter or ...
         } 
         		
         // create a temp file with faulty code 
         String tempfolder = foldername;
         tempfolder = tempfolder + "/" + faultyFilename.substring(0, faultyFilename.length()-suffix.length());
         
         tempfolder = tempfolder.replace(user, (user + "/" + "temp"));
         File tempDir = new File(tempfolder);
         if (! tempDir.exists())
         {
            if ( !makeDir(tempfolder))
               out.println("<br /> tempfolder " + tempfolder + " cannot be created");
         }        
         writeToFile(tempfolder, outfilename, edited_str);        
         
         try
         {
            File tempfile = new File(tempfolder, outfilename);          
            if (!tempfile.exists())
            {
             //  out.println("<br /> tempfile " + tempfile.getAbsolutePath() + " does not exist. " );
            }
            else 
            {	
               tempDir.setExecutable(true, false);
               tempfile.setExecutable(true, false);
               
///////////////////////////////////////////////////////////////////////////////////               
            	            	
               String str_compileResult = compileFile(tempfolder, tempfile, rootFolder);
        	   if (! str_compileResult.equals("success") )
               {
        		  // update session info  
        		  session.setAttribute ("compileError", "Yes");
        		  session.setAttribute ("errorCode", edited_str);
        		  if (button.equals("Generate"))
        		     session.setAttribute ("msg","[Errors] Compilation errors. No fault generated.");
        		  else if (button.equals("Update"))
        			 session.setAttribute ("msg","[Errors] Compilation errors. No fault updated.");
        		  
        		  session.setAttribute ("detailErrorMsg", str_compileResult);
        		  session.setAttribute ("selectedFile", selectedFile);
        		  session.setAttribute ("orgCode", org_str);

                  if (! tempfile.delete() )
                	 out.println("<br />Cannot delete an uncompilable tempfile " + tempfile + '\n');
               }
        	   else 
        	   {
        		  //////////////////////////////////////// 
        		  //   for action = "Generate"
        	      if (button.equals("Generate"))
        	      {
                     session.setAttribute("action", "Generate");
 
                     String log_filename = foldername + "/" + faultyFilename.substring(0, faultyFilename.length()-suffix.length()) + "_log.txt";
        		     int totalFaults = getTotalFaultsFor(log_filename) + 1;
        		  
        	         String resultfolder = tempfolder.replace( (user + "/" + "temp"), user)  + "_" + totalFaults;
        	         File resultDir = new File(resultfolder);
        	         if (! resultDir.exists())
        	         {
        	            if ( !makeDir(resultfolder))
                           out.println("<br /> Cannot create result folder " + resultfolder + '\n');
        	         }
        	      
         		     File temp_dir = new File(tempfolder);
         		     FileUtils.copyDirectory(temp_dir, resultDir);

                     // update log for this target file                     
                     String log_str = resultDir.getAbsolutePath() + ":" + "\n";  
                     String updatelog_status = updateLog(log_filename, log_str, "Generate");
                  
        		     session.setAttribute ("msg", "Compilation successful. Fault generated : " +
				             faultyFilename.substring(0, faultyFilename.length()-suffix.length()) + "_" + totalFaults );
        	      }
        	      
                  /////////////////////////////////////////////
                  //   for action = "Update"
                  //   don't generate a file w/ new faultID, just update the existing (given) fault
        	     
    	          if (button.equals("Update"))
    	          {
    	         	 session.setAttribute("action", "Update");
                     
    	        	 String retrievedFile = (String)session.getAttribute("faultyFile");
    	        	 if (retrievedFile != null && retrievedFile.length() > 0)
    	        	 {
                        String temp_str = "/faultseeding_result/" + user + "/";
                        String fault_id = retrievedFile;
                        if (fault_id != null & fault_id.length() > 0)
                        {
                           int j = fault_id.indexOf(temp_str);
    	                   if ( (j > 0) && ((j+temp_str.length()) < fault_id.length()) )
    	                   	  fault_id = fault_id.substring( (j + temp_str.length()), fault_id.length());
    	                }
	
    	                File file = new File(retrievedFile);
    	                File faultyfile = new File(file.getParent());
    	                if (!faultyfile.exists())
    	                {
    	           		   session.setAttribute ("msg", ("[Errors] " + fault_id + " -- Faulty version does not exist. Cannot updated") );
     	                }
    	                else 
    	                {  
    	                   String log_filename = new String();
    	                   int i = (faultyfile.getAbsolutePath()).lastIndexOf("_");
    	                   if (i > 0)
    	                   {
    	                      log_filename = (faultyfile.getAbsolutePath()).substring(0, i) + "_log.txt";
    	                      String log_str = faultyfile.getAbsolutePath() + ":Updated-on-" + (new Date()).getTime();  
    	                      String updatelog_status = updateLog(log_filename, log_str, "Update");
    	                      
    	                      File temp_dir = new File(tempfolder);
    	                      String retrievedFaultyFolder = retrievedFile.substring(0, retrievedFile.lastIndexOf("/"));
    	                      File retrievedDir = new File(retrievedFaultyFolder);
    	                      FileUtils.copyDirectory(temp_dir, retrievedDir);
    	                      session.setAttribute ("msg", ("Compilation successful. Fault updated : " + fault_id));
    	                   }
    	                   else
    	             		  session.setAttribute ("msg", ("[Errors] " + fault_id + " -- Cannot retrieve/update log file.") );
    	                }

    	        	 }
    	          }             
                  
                  /////////////////////////////////////////////
                  
                  // reset info of this session for next request 
        		  session.setAttribute ("compileError", "No");
        		  session.setAttribute ("errorCode", "");
        		  session.setAttribute ("detailErrorMsg", "");
        		  session.setAttribute ("selectedFile", selectedFile);
        		  session.setAttribute ("faultyFile", "");
        		  session.setAttribute ("orgCode", org_str);
        		  
        		  
        	   }
            }
         } catch (Exception e) { System.out.println("[Errors]: cannot compiletemp file : " + e.toString());  e.printStackTrace();  }       	       
      }
      
      doGet(request, response);
   }
      
   
   /**
    * Given a target filename, read its corresponding fault-seeded log 
    * and retrieve total number of faults (each line contains info for each fault seeded)
    * @param filename
    * @return line_no -- number of faults
    */
   private int getTotalFaultsFor(String filename)
   {
	  int line_no = 0;
      try 
      {
          File file = new File(filename);
          FileReader fileReader = new FileReader(file);               
          BufferedReader bufferedReader = new BufferedReader(fileReader);
          String text = new String();
          while ( (text = bufferedReader.readLine()) != null)
          {
       	     line_no++;
          }
          bufferedReader.close();
       } catch (Exception e)
       {
          System.out.println("Error in doGet(), read input stream: " + e);	
       }
       return line_no;
   }
   
   
   /**
    * Update fault-seeded log for a given filename
    * Format --  faultId:absolute path to this fault:action
    * (action -- Generate, Open, Reset, Retrieve, Update, Delete)
    * @param filename
    * @param str
    * @param action
    * @return status -- whether log is updated successfully
    */
   private String updateLog(String filename, String str, String action)
   {
	  String status = action;
	  
	  // e.g., str = /Applications/apache-tomcat-7.0.35/webapps/tool/WEB-INF/faultseeding_result/username/fileLoad_2:Delete
	  int i = str.lastIndexOf("/");
	  int j = str.lastIndexOf(":");
	  String faultID = new String();
	  if (i > 0 && i < j && j > 0 && j < str.length())
		 faultID = str.substring(i+1, j);
	 
	  str = faultID + ":" + str;
	  // e.g., fileLoad_2:/Applications/apache-tomcat-7.0.35/webapps/tool/WEB-INF/faultseeding_result/username/fileLoad_2:action

	  if (action.contains("Delete") || action.contains("Update") )
      {
    	 // Read each line from original log file and write to temp log file.
    	 // Then, replace the original log file with a ntew temp log file.
    	 try
    	 {
    		File orglogfile = new File(filename);
    		BufferedReader bufferedReader = new BufferedReader(new FileReader(orglogfile));
    		
    		String temp_filename = filename;
    		temp_filename = temp_filename.replace(user, (user + "/" + "temp"));    		
    		int n = temp_filename.lastIndexOf("/");
    		String temp_folder = temp_filename.substring(0, n);
    				
            File tempDir = new File(temp_folder);
            if (! tempDir.exists())
            {
               if ( !makeDir(temp_folder))
            	  status = "action =" + action + " : " + temp_folder + " does not exist, cannot makeDir!!!";
            }                
            
            File temp_file = new File(temp_filename);            
   	        PrintWriter pw = new PrintWriter(new FileWriter(temp_file)); 
   	        
            String line = "";
            String str_line = "";

            while ((line = bufferedReader.readLine()) != null)
            {
               if (line.contains(faultID + ":"))
                  str_line = str;      // replace log of this faultID with new str (marked with "Delete")
               else
                  str_line = line;
               
               status = status + " : str_line =" + str_line ;
               
               pw.println(str_line);
               pw.flush();
            }
            pw.close();
            bufferedReader.close();
            
            FileUtils.copyFile(temp_file, orglogfile);  // replace original log file w/ "Deleted" or "Updated" marked to the given faultID
            
            status = status + "-success";
            
    	 } catch (Exception e)
    	 {  System.out.println("[Errors] in faultSeedingServlet.updateLog (" + action + ") :" + e); }
      }
      else
      {
	     try 
	     {
		    FileWriter out = new FileWriter(filename, true);
		    out.append(str);
		    out.flush();
		    out.close(); 
		    status = "generate-success"; 
	     } catch (Exception e)
	     { System.out.println("[Errors]] in faultSeedingServlet.updateLog : (generate)" + e); }
      }
      
      return status;
   }

   
   /**
    * Write faulty code to file, i.e., faulty version of a given targeted filename
    * @param foldername
    * @param filename
    * @param str
    */
   private void writeToFile(String foldername, String filename, String str)
   {
	  String temp_str = str;
	  String out_str = new String();
	//  boolean firstline = true;
	  
	  // because line_no was attached to each line to display on screen (textarea)
	  // the extra info must be excluded before writing to file 
	  // for later compiled by java compiler 
	  
	  int n = 0; 
	  while ( (n = temp_str.indexOf('\n')) > 0 )
	  {
		 String line_str = temp_str.substring(0,  n);
		 temp_str = temp_str.substring(n+1, temp_str.length());
		 int i = line_str.indexOf(":");
		 if (i > 0)
		    out_str = out_str + line_str.substring(i+1, line_str.length()) + '\n';
	  }
	  
      try
      {
         File file = new File(foldername, filename);         
         FileWriter fout = new FileWriter( file);
         fout.write(out_str);
         fout.flush();
         fout.close();
      } catch (IOException e)
      { System.out.println("Error: cannot write to file " + foldername + filename + " : " + e.toString());  e.printStackTrace();  }
   }
   
   
   /**
    * Check if a given file is compilable (using java compiler)
    * 27-May-2014: current version of faultSeedingServlet supports only java servlet (can't check/compile jsp yet)  
    * @param foldername
    * @param f
    * @param rootFolder
    * @require foldername must exist
    * @return compileResult -- success or compile error message via java compiler's diagnostics 
    * @throws IOException
    */
   private String compileFile(String foldername, File f, String rootFolder) throws IOException
   {
      if ( (f.getAbsolutePath()).indexOf(".jsp") > 0)
    	 return "success";
	   
      String compileResult = "";
      
      ArrayList<String> fnames = new ArrayList<String>();
      fnames.add(f.getAbsolutePath());
      
	  if (rootFolder != null && rootFolder.length() > 0)
	  {
		 try 
	     {   // list all target files assigned to this UserID
	        Vector fileVector = getNewTargetFiles(rootFolder);
	        for (int i=0; i<fileVector.size(); i++)
	        {
               File temp = new File(fileVector.elementAt(i).toString());
               if ( !(temp.getName()).equals(f.getName()) && 
            		 (temp.getName().indexOf(".java") > 0) )    // to check for compile error, currently support only java
               {
	        	  fnames.add(ASSIGNED_DIR  + "/" + fileVector.elementAt(i).toString());
               }
	        }
	     } catch (Exception e)
	     {
            System.out.println("Error in faultSeedingServlet.doGet listing file from ASSIGNED_DIR: " + e.toString());
         }
	  }
      	  
      JavaCompiler compiler = ToolProvider.getSystemJavaCompiler();
	       
      DiagnosticCollector<JavaFileObject> diagnostics = new DiagnosticCollector<JavaFileObject>();
      StandardJavaFileManager fileManager = compiler.getStandardFileManager(diagnostics, null, null);      

      Iterable<? extends JavaFileObject> compilationUnits = fileManager.getJavaFileObjectsFromStrings(fnames);

	  List<String> compileOption = new ArrayList<String>();
	  	  
	  compileOption.addAll(Arrays.asList("-classpath", "/Applications/apache-tomcat-7.0.54/webapps/experiment/WEB-INF/lib/servlet-api.jar"));

      // specify where to place the output files --> under "faultseeding_result" folder
      String resultpath = foldername;
   
      // tell compiler where to place output files
      compileOption.addAll(Arrays.asList("-d", resultpath));
      JavaCompiler.CompilationTask task = compiler.getTask(null, fileManager, diagnostics, compileOption, null, compilationUnits);
      
      boolean status = task.call();
      if (!status) 
      {  //If compilation error occurs 
         // Iterate through each compilation problem and print it
         for (Diagnostic diagnostic : diagnostics.getDiagnostics()) 
         {
        	error_cnt++;
            compileOption.add("\n" + diagnostic.getKind().toString() + " on line  "+ diagnostic.getLineNumber() +"\n\n In file:  \n"+ diagnostic.toString()+"\n\n");
         }

         for (int i=0; i<compileOption.size(); i++)
         {
        	if ( (compileOption.get(i).toString()).contains("ERROR") )
               compileResult = compileResult + compileOption.get(i).toString() + "<br />";
         }
      }
      else 
         compileResult = "success";
            
      try 
      {
         fileManager.close();   
      } catch (IOException e) 
      {  e.printStackTrace();  }

      return compileResult;    
   }


   //////////////////////////////////////////////////////////////////////////////////////////
   
   
   public void PrintHead(PrintWriter out)
   {
      out.println("<?xml version=\"1.0\" encoding=\"UTF-8\"?>"); 
      out.println("<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" " +  
			              " \"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd\"> "); 
      out.println("<html xmlns=\"http://www.w3.org/1999/xhtml\" xml:lang=\"en\" lang=\"en\">" );
 
      out.println("<head>");
      out.println("   <meta http-equiv=\"content-type\" content=\"text/xhtml; charset=utf-8\">");
      out.println("   <meta name=\"description\" content=\"Fault Seeding Tool\">");
      out.println("   <meta name=\"keywords\" content=\"fault, seeding, tool\">");
      out.println("   <title>Fault Seeder</title>");
       
      out.println ("<script type=\"text/javascript\" src=\"" + clienthintjsLocation + "\"></script>");
      
      out.println("   <style>");
      out.println("      body, html {");
      out.println("         margin: 0 auto;");
      out.println("         padding: 0;");
      out.println("         color: #202020;");
      out.println("         background-color: #ddeeff;");
      out.println("         font-family: 'Lucida Grande',Verdana,Helvetica,Arial,Geneva,'Bitstream Vera Sans',Sans-Serif;");
      out.println("         font-size: 12px;");
      out.println("      }");     
         
      out.println("      input[type=text], textarea {");  
      out.println("         border: 1px solid #cccccc;");
      out.println("         font: 11px Verdana;"); 
      out.println("         color: black;"); 
      out.println("         line-height: 1.2em;"); 
      out.println("      }");

      out.println("      #top {");
      out.println("         padding-top: 12px;");
      out.println("         padding-left: 10px;");
      out.println("         padding-right: 4px;");
      out.println("         float: left;");
      out.println("         text-align: justify;");
      out.println("         width: 90%;");
      out.println("     	}");

      out.println("      #main {");
      out.println("         padding-top: 12px;");
      out.println("         padding-left: 10px;");
      out.println("         padding-right:4px;");
      out.println("         float: left;");
      out.println("         width: 90%;");
      out.println("         text-align: center;");
      out.println("      }");
         
      out.println("      #note {");
      out.println("         font: 10px Verdana;");
      out.println("         color: red;");
      out.println("      }");
         
      out.println("      .faultyCode {");
      out.println("         width: 100%; ");
      out.println("      }");
         
      out.println("      .orgCode {");
      out.println("         background-color: #eeeeee;");
      out.println("         width: 100%; ");
      out.println("      }");

      out.println("      .errorMsg {");
      out.println("         background-color: #eeeeee;");
      out.println("         width: 100%; ");
      out.println("      }");

      out.println("      .list {");
      out.println("         width: 90%;");
      out.println("         background-color: #eeeeee;");
      out.println("      }");
         
      out.println("   </style>");
      out.println("</head>");     
   }
   

   public void PrintBody(PrintWriter out, String org_str, String edited_str)
   {
      out.println("<body >");
      
      out.println("<script type=\"text/javascript\" src=\"" + wztooltipjsLocation + "\"></script>");
      
      out.println("   <table width=\"25%\" align=\"right\" bgcolor=\"#E0E0E0\" border=\"0\" cellspacing=\"2\" cellpadding=\"5\"");
      out.println("     <tr>");
      out.println("       <td align=\"right\">UserID:  " + user + "</td>" );
      out.println("       <td>");
      out.println("         <form action=\"" + LogoutServlet  + "\" method=\"post\">");
      out.println("            <input type=\"submit\" value=\"Logout\" " + 
                                 " onMouseOver=\"Tip('Logout from the Fault Seeding System. <br /> Thank you " + user + ".')\" " + 
                                 " onMouseOut=\"UnTip()\"></input>");     
      out.println("         </form>");
      out.println("       </td>");
      out.println("     </tr>");
      out.println("   </table>");

      out.println("   <!-- top panel -->");
      out.println("   <center><h1>Fault Seeding System</h1></center>");

      out.println("   <div id=\"top\">");
      PrintTopPanel(out);
      out.println("   </div>");
         
      out.println("   <form name=\"mainform\" id=\"mainform\" onSubmit=\return submitIt(this)\" "
                           +  "method=\"POST\" " +  "action=" + SERVLET_PATH + ">");

      out.println("   <!-- main panel -->");
      out.println("   <div id=\"main\">");
      PrintMainPanel(out, org_str, edited_str);
      out.println("   </div>");
      out.println("   </br>");
         
      out.println("   <!-- button panel -->");
      PrintBottomPanel(out);
      
      PrintErrorMessage(out);
      
      out.println("   </form>");
    
   }
   
   
   public void PrintTopPanel(PrintWriter out)
   {
      out.println("   <table width=\"95%\" align=\"center\" style=\"border:none\" summary=\"Layout for main content of the page\" >");      
      
      out.println("      <tr>");
      out.println("         <td colspan=2 align=\"center\">");
      out.println("         Choose the file to insert faults. " 
    	 		            + "<b>Please introduce only <font color=\"red\">ONE</font> fault for each faulty version.</b> <br />" );
      out.println("         </td>");
      out.println("      </tr>");
      
      out.println("      <tr>");
      out.println("         <td >");
      out.println("         <form name=\"selectFileForm\" method=\"POST\" " + "action=" + SERVLET_PATH + ">");
      out.println("            <table>");		           
      out.println("              <tr>");
      out.println("                <td align=\"right\">*Select File: </td>");
      out.println("                <td>");
      out.println("                   <select name=\"targetfile\" id=\"targetfile\" >");
      out.println("                      <option value=\"PleaseSelect\">Please select</option>");
      try 
      {   // list all target files assigned to this UserID
         Vector fileVector = getNewTargetFiles();
         for (int i=0; i<fileVector.size(); i++)
            out.println("<option value=" + fileVector.elementAt(i) + ">" + fileVector.elementAt(i) + "</option>" );
      } catch (Exception e)
      {
    	 System.out.println("Error in faultSeedingServlet.doGet listing file from ASSIGNED_DIR: " + e.toString());
      }
      out.println("                   </select><input type=\"submit\" name=\"btn\" value=\"Open\" " +
                                              " onMouseOver=\"Tip('Open a file to insert faults')\" " + 
                                              " onMouseOut=\"UnTip()\"></input>");

      out.println("                </td>");
      out.println("              </tr>");
      out.println("              <tr><td></td><td></td></tr>");
      out.println("              <tr>");
      if ( (selectedFile != null) && (selectedFile.length() > 0) && !(selectedFile.equalsIgnoreCase("PleaseSelect")) )
	     out.println("               <td colspan=\"2\"><b>Current selected file :  <mark>  " + selectedFile + "  </mark></b></td>");
      else
         out.println("               <td>&nbsp;&nbsp;</td>");
      out.println("              </tr>");
          
      out.println("              <tr>");
      if (msg != null) 
      {
    	 if (msg.contains("[Errors]"))
    	 {
            out.println("                <td colspan=\"2\" bgcolor=\"yellow\"> <font color=\"red\"><b>" + msg );
            if ( (msg.contains("Faulty version does not exist")) || (msg.contains("Cannot retrieve a faulty version")) )
               out.println("  ");
            else 
               out.println(" See below for details.");
            out.println(" </b></font></td>");
    	 }
         else
         {
        	if ( (msg.contains("Reset screen")) || (msg.contains("Open selected file")) )
               out.println("                <td>&nbsp;&nbsp;</td>");
        	else       
               out.println("                <td colspan=\"2\" bgcolor=\"yellow\"> " +
                                              "<font color=\"green\"><b>" + msg + "</b></font></td>");
         }
      }
      else
    	  out.println("              <td>&nbsp;&nbsp;</td>");
      out.println("              </tr>");

      out.println("            </table>");
      out.println("         </form>");      
      out.println("         </td>");

      out.println("         <td align=\"justify\">");
      out.println("            <table border=0 cellpadding=2");
      out.println("               <tr>");
      out.println("                  <td>");
      out.println("                    <ul>"  
                                 + "     <li>After modifying the code, press the <b>\"Generate\"</b> button to create a faulty version file. </li>"
                                 + "     <li>To update, retrieve an existing fault from the list, modify the code and " 
                                 + "         press the <b>\"Update\"</b> button. </li>" 
                                 + "     <li>To delete, retrieve an existing fault from the list and press " 
                                 + "         the <b>\"Delete\"</b> button. </li>" 
                                 + "   </ul>" );
      out.println("                 </td>");
      out.println("               </tr>");
      out.println("            </table>");
      out.println("         </td>");
      out.println("      </tr>");
      
      out.println("   </table>");

   }
   
      
   public void PrintMainPanel(PrintWriter out, String org_str, String edited_str)
   {
	  int totalFaults = 0;
	  String log_filename = "";
	  String subfolder = "";
      if (selectedFile != null && selectedFile.length() > 0)
      {
    	 log_filename = selectedFile;
         int j = selectedFile.indexOf(".");
         if (j > 0 && j < log_filename.length())
        	log_filename = log_filename.substring(0, j);
    	 
         int i = selectedFile.lastIndexOf("/");
         if (i > 0 && i < log_filename.length())
         {
        	subfolder = log_filename.substring(0, i);
        	log_filename = log_filename.substring(i+1, log_filename.length());
         }
         
         if (subfolder != null && subfolder.length() > 0)
        	log_filename = RESULT_DIR + "/" + user + "/" + subfolder + "/" + log_filename + "_log.txt";
         else 
            log_filename = RESULT_DIR + "/" + user + "/" + log_filename + "_log.txt";
         
         totalFaults = getTotalFaultsFor(log_filename);
      }
      
	  out.println("   <table border=\"1\" width=\"95%\">");
      out.println("      <tr>");
      out.println("         <td width=\"10%\">");
      out.println("            <table align=\"top\">");
      out.println("               <tr>");
      out.println("                  <td>List of faults: <br />");
      out.println("                      <select size=15 name=\"listFault\" id=\"listFault\">");

      try 
      {   // list all fault of this target file
         Vector faultVector = getFaultsFor(log_filename);
         for (int i=0; i<faultVector.size(); i++)
            out.println("<option value=" + ((Fault)faultVector.elementAt(i)).fault_location + ">" + ((Fault)faultVector.elementAt(i)).fault_id + "</option>" );
      } catch (Exception e)
      {
    	 System.out.println("Error in faultSeedingServlet -- list all existing faults from " + log_filename + " : " + e.toString());
      }
      
      out.println("<option value=\"PleaseSelect\">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</option>");
      
      out.println("                     </select>");
      out.println("                  </td>");
      out.println("               </tr>");
      out.println("               <tr>");
      out.println("                  <td>");
      if ( (selectedFile != null) && (selectedFile.length() > 0) && !(selectedFile.equalsIgnoreCase("PleaseSelect")))
         out.println("                     <input type=\"submit\" name=\"btn\" value=\"Retrieve\" " +
                                            " onMouseOver=\"Tip('Retrieve the selected faulty version')\" " + 
                                            " onMouseOut=\"UnTip()\"></input>");
      else
    	 out.println("                     <input disabled type=\"submit\" name=\"btn\" value=\"Retrieve\"></input>");
      out.println("                  </td>");
      out.println("               </tr>");
      out.println("               <tr><td>&nbsp;&nbsp;</td></tr>");
      out.println("               <tr>");
      out.println("                  <td>");
      out.println("                     <label for=\"TotalFault\" id=\"lblTotalFault\">Total Faults: " + totalFaults + "</label>");
      out.println("                  </td>");
      out.println("               </tr>"); 
      out.println("            </table>");    	 
      out.println("         </td>");

      String fault_id = infilename;
      String temp_str = "/faultseeding_result/" + user + "/";
      if (fault_id != null && fault_id.length() > 0 && fault_id.contains(temp_str))
      {
            int m = fault_id.indexOf(temp_str) + temp_str.length();
            if (m > 0 && m < fault_id.length())
               fault_id = fault_id.substring(m, fault_id.length());
      }
      else 
    	 fault_id = " ";
      
      // display code for seeder to make change/insert fault
      out.println("         <td width=\"45%\" align=\"center\">");
      out.println("            <h3>*Enter fault " + "<br /> (Existing fault retrieved : <span style=\"color:green;font-weight:bold\">" + fault_id + "</span>) </h3>");
      out.println("            <textarea class=\"faultyCode\" rows=\"20\" col=\"80\" name=\"txtFaultyCode\" id=\"txtFaultyCode\" wrap=\"soft\" ");
      out.println("                 placeholder=\" Please select a file to begin\" >" );
      if ( (msg.contains("Faulty version does not exist")) || (msg.contains("Faulty version deleted")) || 
           (msg.contains("Compilation successful. Fault updated")) )
    	 out.println("  ");
      else
    	 out.println( edited_str );
      out.println("            </textarea>");
      out.println("         </td>");
         
      out.println("         <td width=\"45%\" align=\"center\">");
      out.println("            <h3>Original Code <br /> (Original file : ");
      if (selectedFile != null & selectedFile.length() > 0)
    	 out.println(selectedFile);
      else 
    	 out.println("   ");
      out.println(" ) </h3>");
      out.println("            <textarea class=\"orgCode\" rows=\"20\" column=\"80\" name=\"txtOrgCode\" id=\"txtOrgCode\" "
        		                       + " readonly=\"readonly\" wrap=\"soft\" >");
      out.println("            " + org_str + " </textarea>");         
      out.println("         </td>");
         
      out.println("      </tr>");
      out.println("   </table>");
      out.println("   </br>");
   }
      
   
   public void PrintBottomPanel(PrintWriter out)
   {    	  
      out.println("   <table border=\"0\" align=\"center\" width=\"80%\">");
      out.println("      <tr>");
	     
      out.println("         <td>");
      if ( (selectedFile != null) && (selectedFile.length() > 0) && !(selectedFile.equalsIgnoreCase("PleaseSelect")) &&
          	   !(msg.contains("Faulty version does not exist")) && !(msg.contains("Faulty version deleted")) && 
          	   !(msg.contains("Compilation successful. Fault updated")) )        		  
         out.println("            <input type=\"submit\" value=\"Generate\" Name=\"btn\" " + 
                                   " onMouseOver=\"Tip('Compile and generate a faulty version')\" " + 
        		                   " onMouseOut=\"UnTip()\"></input>");
      else
         out.println("            <input disabled type=\"submit\" value=\"Generate\" Name=\"btn\" ></input>");
      out.println("         </td>");

      out.println("         <td>");
      if ( (selectedFile != null) && (selectedFile.length() > 0) && !(selectedFile.equalsIgnoreCase("PleaseSelect")) && 
    	   !(msg.contains("Faulty version does not exist")) && !(msg.contains("Cannot retrieve a faulty version")) &&
    	   !(msg.contains("Faulty version deleted")) && !(msg.contains("Compilation successful. Fault generated")) &&
    	   !(msg.contains("Reset screen")) && !(msg.contains("Open selected file")) && 
    	   !(msg.contains("No fault generated")) && !(msg.contains("Compilation successful. Fault updated")) )
         out.println("            <input type=\"submit\" value=\"Update\" name=\"btn\" " +
                                   " onMouseOver=\"Tip('Update the selected faulty version')\" " + 
                                   " onMouseOut=\"UnTip()\"></input>");
      else
    	 out.println("            <input disabled type=\"submit\" value=\"Update\" name=\"btn\"></input>");
      out.println("         </td>");

      out.println("         <td>");
      if ( (selectedFile != null) && (selectedFile.length() > 0) && !(selectedFile.equalsIgnoreCase("PleaseSelect")) && 
       	   !(msg.contains("Faulty version does not exist")) && !(msg.contains("Cannot retrieve a faulty version")) && 
       	   !(msg.contains("Faulty version deleted")) && !(msg.contains("Faulty version updated")) &&
       	   !(msg.contains("Compilation successful. Fault generated")) && !(msg.contains("Compilation errors.")) && 
       	   !(msg.contains("Reset screen")) && !(msg.contains("Open selected file")) &&
       	   !(msg.contains("Compilation successful. Fault updated")) ) 
         out.println("            <input type=\"submit\" value=\"Delete\" name=\"btn\" " +
                                   " onMouseOver=\"Tip('Delete the selected faulty version. <br /> The faulty version will be <b>removed permanently</b>. <br /> <b>This action cannot be undone</b>.')\" " + 
                                   " onMouseOut=\"UnTip()\"></input>");
      else
    	 out.println("            <input disabled type=\"submit\" value=\"Delete\" name=\"btn\"></input>");
      out.println("         </td>");
       
      out.println("         <td>");
      if ( (selectedFile != null) && (selectedFile.length() > 0) && !(selectedFile.equalsIgnoreCase("PleaseSelect")) &&
           !(msg.contains("Faulty version deleted")) && !(msg.contains("Faulty version updated")) )
         out.println("            <input type=\"submit\" value=\"Reset\" name=\"btn\" " +
                                   " onMouseOver=\"Tip('Reset all modification of the current form. <br /> Open the most recently selected file.')\" " + 
                                   " onMouseOut=\"UnTip()\"></input>");
      else
    	 out.println("            <input disabled type=\"submit\" value=\"Reset\" name=\"btn\"></input>");
      out.println("         </td>");

      out.println("<script language=\"javascript\" type=\"text/javascript\">"); 	   
      out.println("      function resetFaultyCode(txtFaultyCode) ");
      out.println("      {");
      out.println("         txtElement.value = " + selectedFile );
      out.println("         ");
      out.println("      }");
      out.println("</script>");
      
      out.println("         <td>");
      if ( (selectedFile != null) && (selectedFile.length() > 0) && !(selectedFile.equalsIgnoreCase("PleaseSelect")))
    	 out.println("            <input type=\"submit\" value=\"Clear\" name=\"btn\" " +
                                   " onMouseOver=\"Tip('Clear the form')\" " + 
                                   " onMouseOut=\"UnTip()\"></input>");
      else
         out.println("            <input disabled type=\"submit\" value=\"Clear\" name=\"btn\"></input>");
      out.println("         </td>");
      out.println("      </tr>");
      out.println("   </table>");
   }
 
   
   public void PrintErrorMessage(PrintWriter out)
   {
	  if (detail_error_msg != null && detail_error_msg.length() > 0)
	  {
		 out.println("<a name=\"errorMsg\"></a>");
		 out.println("<hr>");
         out.println("<table align=\"center\" width=\"95%\">");
         out.println("   <tr>");
         out.println("      <td><b><mark>  Currently selected file: " + selectedFile + " : " + error_cnt + " </mark></b></td>");
         out.println("   </tr>");
         
         out.println("   <tr>");
         out.println("      <td>");         
         out.println(         detail_error_msg + " <br /><br />");
         out.println("      </td>");
         out.println("   </tr>");
         out.println("</table>");
	  } 
   }
   
   
   //////////////////////////////////////////////////////////////////////////////////////////

   private void resetAllVariables()
   {
 	  selectedFile = new String();   
 	  infilename = new String(); 
 	  outfilename = new String();     
 	  org_str = new String();                 
  	  edited_str = new String(); 	
 	  foldername = new String();
 	  suffix = new String();   
 	  user = new String();
      msg = new String();
      detail_error_msg = new String();
      error_cnt = 0;
   }

	
   /**
    * Make directory / folder for a given path
    * @param dirPath
    * @return true -- successfully create directory, false otherwise
    */
   private Boolean makeDir(String dirPath)  
   {
	  boolean dirFlag = false;	  
      File prjDir = new File(dirPath);
      try 
      {
    	 if (! prjDir.exists())
    	 {
            dirFlag = prjDir.mkdirs();
            return dirFlag;
    	 }
      } catch (SecurityException Se) 
      {
         System.out.println("Error while creating directory in Java:" + Se);
      }
      return dirFlag;    
   } 


   
   /**
    * Given a log_filename, return un-deleted faultIDs and thier coresponding folder/location
    * log file format e.g., fileLoad_2:/Applications/apache-tomcat-7.0.35/webapps/tool/WEB-INF/faultseeding_result/demo/fileLoad_2:Deleted-on-datetime
    * @param filename
    * @return faultVector - list of un-deleted faultID of a given target filename
    */
   private Vector getFaultsFor(String filename)
   {
	  Vector faultVector = new Vector();
      try 
      {
         File file = new File(filename);
         FileReader fileReader = new FileReader(file);               
         BufferedReader bufferedReader = new BufferedReader(fileReader);
         String text = new String();
         while ( (text = bufferedReader.readLine()) != null)
         {
        	if ( !(text.contains(":Deleted-on-")) )
        	{        	
               String fault_id = "";
               String fault_location = "";
            
       	       int i = text.indexOf(":"); 
        	   if (i > 0)      
                  fault_id = text.substring(0, i); 
        	
        	   int j = text.lastIndexOf(":");
        	   if (j > 0)
                  fault_location = text.substring(i+1, j);
        		 
               Fault F = new Fault(fault_id, fault_location);
               faultVector.addElement(F);
        	}
          }
          bufferedReader.close();
       } catch (Exception e)
       {
          System.out.println("Error in getFaultsFor() : " + e);	
       }
       return faultVector;
   }
   

   /**
    * Write output string (faulty code) to file
    * @param out
    * @param filecontent
    * @param request
    */
   private void writeToFile(PrintWriter out, String filecontent, HttpServletRequest request)  
   {
      FileWriter fw = null;
      PrintWriter pw = null;
	 
      try
      {
         fw = new FileWriter(filecontent, true);      // get file output stream
         pw = new PrintWriter(fw);
		 
         pw.println(filecontent);
	  } catch (Exception e)
      {
         System.out.println("error in saveFile: " + e );
      } finally
      {
         try
         {
            pw.flush();     // flush output stream to file
            pw.close();     // close print writer
         } catch (Exception ignored)    { }
         try
         {
            fw.close();
		 } catch (Exception ignored)    { }
      }
   }
   

   /**
    * Set up a list of files being considered (insert fault)
    * @param dir
    * @return
    */
   private static Vector getNewTargetFiles(String dir)
   {
      Vector targetFiles = new Vector();
      getJavacArgForDir (dir, "", targetFiles);
      return targetFiles;
   }
   
    
   /**
    * Set up target files (stored in src folder) to be tested
    * @return
    */
   private static Vector getNewTargetFiles()
   {
      Vector targetFiles = new Vector();
      getJavacArgForDir (ASSIGNED_DIR, "", targetFiles);
      return targetFiles;
   }

     
   /**
    * Retrieve target files to be listed for participants to insert faults 
    * @param dir
    * @param str
    * @param targetFiles
    * @return result -- list of target files 
    */
   protected static String getJavacArgForDir (String dir, String str, Vector targetFiles)
   {
      String result = str;
      String temp = "";

      File dirF = new File(dir);
      File[] javaF = dirF.listFiles (new ExtensionFilter("java"));      
      if (javaF.length > 0)
      {
         result = result + dir + "/*.java ";
         
         for (int k=0; k<javaF.length; k++)
         {
            temp = javaF[k].getAbsolutePath();
            temp.replace('\\', '/');
            targetFiles.add(temp.substring(ASSIGNED_DIR.length()+1, temp.length()));
         }
      }
      
      File[] jspF = dirF.listFiles(new ExtensionFilter("jsp"));
      if (jspF.length > 0)
      {
         result = result + dir + "/*.jsp ";
         for (int k=0; k<jspF.length; k++)
         {
            temp = jspF[k].getAbsolutePath();
            temp.replace('\\','/');
            targetFiles.add(temp.substring(ASSIGNED_DIR.length()+1, temp.length()));
         }
      }
      
      File[] htmlF = dirF.listFiles(new ExtensionFilter("html"));
      if (htmlF.length > 0)
      {
         result = result + dir + "/*.html ";
         for (int k=0; k<htmlF.length; k++)
         {
            temp = htmlF[k].getAbsolutePath();
            temp.replace('\\','/');
            targetFiles.add(temp.substring(ASSIGNED_DIR.length()+1, temp.length()));
         }
      }
      
      File[] sub_dir = dirF.listFiles (new DirFileFilter());
      if (sub_dir.length == 0)    return result;

      for (int i=0; i<sub_dir.length; i++)
      {
         result = getJavacArgForDir(sub_dir[i].getAbsolutePath(), result, targetFiles);
      }
      return result;
   }

   
   ////////////////////////////////////////////////////////////////////////////////////////////////////
   // data type for fault
   class Fault
   {
	  // e.g. /Applications/apache-tomcat-7.0.35/webapps/tool/WEB-INF/result/upsorn/fileLoad_1/fileLoad.java
	  //      /Applications/apache-tomcat-7.0.35/webapps/tool/WEB-INF/result/upsorn/computeGPA/gpa_5/gpa.java
      private String fault_id;        // identify which fault	(e.g., fileLoad_1 or gpa_5)
      private String fault_location;  // folder where the fault resides 
      
      public Fault ()   {}
      
      public Fault (String id, String location)
      {
         this.fault_id = id;
         this.fault_location = location;
      }

      public String getFaultID()
      {
    	 return fault_id;
      }
      
      public String getFaultLocation()
      {
    	 return fault_location;
      }
   }

}
