/** *****************************************************************
    login.java  (Fault Seeding System)
        @author Upsorn Praphamontripong
        @version 1.0    (05-May-2014)
    Establishes a login using a servlet session.
    IDs are hardcoded.
    doGet() prints the login screen.
    doPost() checks an ID/password and sets the session info.

Each participant has a unique username-password pair.  
The login servlet checks for valid log in and dispatch a participant
to a fault seeding tool with a list of subjects specifically assigned 
to the participant).  

*********************************************************************
INSTALLATION INSTRUCTIONS
1) Modify faultSeedingServlet.java (Changes marked there)
2) Modify login.java
   Change the following global variables:
   private static String LoginServlet = "http://localhost:8080/experiment/tool.login"; 
   private static String faultSeedingServlet = "http://localhost:8080/experiment/tool.faultSeeder"; 
   public static String FileName = "/Applications/apache-tomcat-7.0.54/webapps/tool/WEB-INF/data/faultseeding-info.xml"; 
   private static String experimentURL = "http://cs.gmu.edu/~uprapha/experiment/faultSeeding.html

   Also change the hard-coded passwords in doPost():
   if (userID.equals ("demo") && passWord.equals ("demo"))
3) Compile .java classes
4) Move .class files to /Applications/apache-tomcat-7.0.54/webapps/tool/WEB-INF/classes/
5) URL:  http://localhost:8080/experiment/tool.login
   URL:  http://localhost:8080/experiment/tool.faultSeeder
   
Note: modify servlet-mapping in tomcat /WEB-INF/web.xml
  <servlet>
    <servlet-name>tool.faultSeedingServlet</servlet-name>
    <servlet-class>tool.faultSeedingServlet</servlet-class>
  </servlet>

  <servlet-mapping>
    <servlet-name>tool.faultSeedingServlet</servlet-name>
    <url-pattern>/tool.faultSeeder</url-pattern>
  </servlet-mapping>
Alternatively, import javax.servlet.annotation.WebServlet and use @WebServlet(“/login”)

**********************************************************************/

package tool;

import javax.servlet.*; 
import javax.servlet.http.*;

import java.io.*;
 
//*********************************************************************


public class login extends HttpServlet
{
   private static final long serialVersionUID = 2L;
   
 //**** setting for local  ****/ 
   private static String LoginServlet = "http://localhost:8080/experiment/tool.login";   
   private static String faultSeedingServlet = "http://localhost:8080/experiment/tool.faultSeeder";  
   private static String experimentURL = "https://cs.gmu.edu/~uprapham/experiment/faultSeeding.html";
   
   // a data file containing participant's name, org_filename (fullpath), fault_filename (fullpath), kind_of_fault
   public static String FileName = "/Applications/apache-tomcat-7.0.54/webapps/tool/WEB-INF/data/faultseeding-info.xml";

   // Form parameters.
   private static String userID;
   private static String passWord;
   // doPost() tells doGet() when the login is invalid.
   private static boolean invalidID = false;

   /** *****************************************************
    *  Overrides HttpServlet's doGet().
    *  prints the login form.
   ********************************************************* */
   public void doGet (HttpServletRequest request, HttpServletResponse response)
          throws ServletException, IOException
   {
      response.setContentType ("text/html");
      PrintWriter out = response.getWriter ();

      out.println ("<html>");
   
      out.println ("<head>");
      out.println ("  <title>Fault Seeding System</title>");
   
      out.println("   <style>");
      out.println("      body, html {");
      out.println("         margin: 0 auto;");
      out.println("         padding: 0;");
      out.println("         color: #202020;");
      out.println("         background-color: #ddeeff;");
      out.println("         font-family: 'Lucida Grande',Verdana,Helvetica,Arial,Geneva,'Bitstream Vera Sans',Sans-Serif;");
      out.println("         font-size: 12px;");
      out.println("      }");     
         
      out.println("      input[type=text] {");  
      out.println("         border: 1px solid #cccccc;");
      out.println("         font: 11px Verdana;"); 
      out.println("         color: black;"); 
      out.println("         line-height: 1.2em;"); 
      out.println("      }");

      out.println("   </style>");

      out.println ("</head>");

      out.println ("<body onLoad=\"setFocus()\" >");
      out.println ("<b><center><h1>Login to Fault Seeding System<h1></center></b>");
   
      if (invalidID)
      {  // called from doPost(), invalid ID entered.
         invalidID = false;
         out.println ("<br><font color=\"red\">Invalid user ID, password pair. Please try again.</font><br><br>");
      }

      out.println ("<form method=\"post\"");
      out.println ("      action=\"" + LoginServlet + "\" id=\"form1\" name=\"form1\">");
      out.println ("  <table Cellspacing=\"0\" Cellpadding=\"3\" Border=\"0\" align=\"center\">");
      out.println ("    <tr>");
      out.println ("      <td>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>");
      out.println ("      <td>UserID:</td>");
      out.println ("      <td><input autofocus type=\"text\" name=\"UserID\" size=\"10\" maxLength=\"20\"><td>");
      out.println ("    </tr>");
      out.println ("    <tr>");
      out.println ("      <td></td>");
      out.println ("      <td>Password:</td>");
      out.println ("      <td><input type=\"password\" name=\"PassWord\" size=\"10\" maxlength=\"20\"></td>");
      out.println ("    </tr>");
      out.println ("    <tr>");
      out.println ("       <td>&nbsp;&nbsp;</td>");
      out.println ("       <td colspan=\"2\" align=\"center\"><input type=\"submit\" value=\"Login\"></input");
      out.println ("     </tr>");
      out.println ("  </table>");
      out.println ("</form>");
      
      out.println ("<center><a href=\"" + experimentURL + "\">Experimental guideline web site (fault seeding)</a></center>");
      
      out.println ("</body>");
      out.println ("</html>");

      out.close ();
   }

   /*******************************************************
    *  Overrides HttpServlet's doPost().
   ********************************************************* */
   public void doPost (HttpServletRequest req, HttpServletResponse res)
          throws ServletException, IOException
   {
      userID   = req.getParameter ("UserID");
      passWord = req.getParameter ("PassWord");

      HttpSession session = req.getSession (true);

      if ( (userID.equals("demo") && passWord.equals ("demo")) )
      {  // successful
         session.setAttribute("isLogin", "Yes");
         session.setAttribute("UserID", userID);
         session.setAttribute("compileError", "");
         session.setAttribute("errorCode","");
         session.setAttribute("msg", "");
         session.setAttribute("selectedFile", "");
         session.setAttribute("faultyFile", "");
         session.setAttribute("detailErrorMsg", "");
    	 session.setAttribute("orgCode", "");    	 
    	 session.setAttribute("action", "");

         res.sendRedirect (faultSeedingServlet);
      }
      else
      {  // unsuccessful
         session.setAttribute("isLogin", "No");
         session.setAttribute("UserID", "");
         session.setAttribute("compileError", "");
         session.setAttribute("errorCode","");
         session.setAttribute("msg", "");
         session.setAttribute("selectedFile", "");
         session.setAttribute("faultyFile", "");
         session.setAttribute("detailErrorMsg", "");
    	 session.setAttribute("orgCode", "");    	 
    	 session.setAttribute("action", "");

         invalidID = true;
         doGet (req, res);
      }
   } 
} 
