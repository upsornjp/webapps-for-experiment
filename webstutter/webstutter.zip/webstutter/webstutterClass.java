package webstutter;

/* Jeff Offutt  - June 1989 (C version)            */
/* stutter checks for repeat words in a text file. */
/* Java version Spring 2008, with help from        */
/* Steven Baker, SWE 437                           */
/* Modified for the web, Ravi Syamala, Spring 2008 */

import java.io.*;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class webstutterClass
{

/**
 * This method reads input feild and prints out the stutters into 
 * the response stream using append. 
 * @param req
 * @param resp
 * @throws IOException
 */
public static void checkStutter (HttpServletRequest req, HttpServletResponse resp) throws IOException
{
   int    numberOfLines = 1;
   String line     = null;
   String lastWord = null;
   String testPassage = (String) req.getParameter("testPassage");
   String array[] = testPassage.split ("\n");
   for (int n=0; n<array.length;n++)
   {
      line = "\n"+array[n]+"\n"; 
      // Remove all non alpha-numeric characters
      // This replaces the IsDelimit() function in the C version.
      line = line.replaceAll ("[^a-zA-Z0-9 ]", "");
      // A small improvement over the C version - ignore case in the comparison
      line = line.toLowerCase();

      // Splits the line into words and puts in an array of strings
      String[] words = line.split (" ");

      // Compare with the last word on the previous line
      if (words [0].equals (lastWord))
         resp.getWriter().append ("\n<li>Repeated word on line " + numberOfLines + ": " + words[0]+"</li>");

      // Stop before the end, nothing to compare the last word with
      for (int i = 0; i < (words.length-1); i++)
      {
         // Check to see if the current and subsequent words are the same
         if (words [i].equals (words [i+1]))
         {
            resp.getWriter().append ("\n<li>Repeated word on line " + numberOfLines + ": " + words [i]+"</li>");
         }
      }

      // Save last word in the line
      lastWord = words [words.length-1];
      numberOfLines++;
   }
}
}
