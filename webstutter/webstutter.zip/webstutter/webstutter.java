package webstutter;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * @author Ravitej Syamala, small modifications Jeff Offutt
 *
 */
public class webstutter extends HttpServlet {

    private static final long serialVersionUID = -3509437421722952331L;
    /**
     * Allows logging into the Catalina logs if needed.     * 
     * @param message
     * @throws IOException
     */
    private void logCrud(String message) throws IOException {
        getServletContext().log(message);
    }

    /* (non-Javadoc)
     * @see javax.servlet.http.HttpServlet#doGet(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        logCrud("webstutter::doGet ==> Begin");
        RequestDispatcher rd;
        logCrud("webstutter::doGet ==> Loading HW2.");
        try {
            rd = getServletContext().getRequestDispatcher("/WEB-INF/classes/webstutter/webstutterInc.html");
            rd.forward(req, resp);
        } catch (Exception exc) {
            logCrud("webstutter::doGet ==> Error, ass: " + exc.getMessage());
        }

    }


    /* (non-Javadoc)
     * @see javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        resp.getWriter().append("<html>\n<head><title>Web Stutter Checker</title>");
        resp.getWriter().append("\n<style type=\"text/css\">");
        resp.getWriter().append("\ndiv.errors { margin: 0 0 10px 0; padding: 5px 10px; border: #FC6 1px solid; background-color: #FFC; }");
        resp.getWriter().append("\ndiv.errors p { margin: 0; }");
        resp.getWriter().append("\ndiv.errors p em { color: #C00; font-style: normal; font-weight: bold; }");
        resp.getWriter().append("\n</style> </head>");
        resp.getWriter().append("\n<body> <h1>Web Stutter Checker, Eric Cykoski & Ravitej Syamala</h1> ");
        resp.getWriter().append("\n<form action=\"http://cs.gmu.edu:8080/uprapham/servlet/webstutter.webstutter\" method=\"POST\">\n");
        resp.getWriter().append("\n<textarea name=\"testPassage\" rows=10 cols=120>" + (String) req.getParameter("testPassage") + "</textarea><br/>");
        resp.getWriter().append("\n<input type=\"submit\" value=\"Submit\">");
        resp.getWriter().append("\n</form>\n <br/>");
        resp.getWriter().append("\n<div class=\"errors\">");
        resp.getWriter().append("\n<p> <em>The following repeated words were found: </em></p>\n<ul>");

        webstutterClass.checkStutter(req, resp);

        resp.getWriter().append("</ul></div>");
        resp.getWriter().append("\n");
        resp.getWriter().append("\n</body>\n</html>");
    }
}
