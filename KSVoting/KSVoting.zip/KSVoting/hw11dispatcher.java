/**
 * SWE 432 - Fall 2012 
 * Maria Kohistani and Peter Schatz
 */

package KSVoting;

import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class hw11dispatcher
 */
public class hw11dispatcher extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
//	private static final String loginPage = "/jsp/pschatz/Login.jsp";
//	private static final String newUserPage = "/jsp/pschatz/NewUser.jsp";
//	private static final String assertionPage = "/jsp/pschatz/assertions.jsp";
//	private static final String assertionXML = "/data/apps-swe432/swe432/WEB-INF/data/pschatzAssertions.xml";

//	private static final String loginPage = "/KSVoting/Login.jsp";
//	private static final String newUserPage = "/KSVoting/NewUser.jsp";
//	private static final String assertionPage = "/KSVoting/assertions.jsp";
//	private static final String assertionXML = "/Applications/apache-tomcat-7.0.54/webapps/experiment/WEB-INF/data/KSVoting/pschatzAssertions.xml";

	private static final String loginPage = "/KSVoting/Login.jsp";
	private static final String newUserPage = "/KSVoting/NewUser.jsp";
	private static final String assertionPage = "/KSVoting/assertions.jsp";
	private static final String assertionXML = "/var/www/CS/webapps/uprapham/WEB-INF/data/KSVoting/pschatzAssertions.xml";

	/**
     * @see HttpServlet#HttpServlet()
     */
    public hw11dispatcher() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		boolean signedin = false;
		HttpSession session = request.getSession();
		//ServletContext application = request.getServletContext();
		RequestDispatcher dispatcher = null;
		
		//get the logged in user's list of votes from the session object, or create a new
		//list if the user has not voted yet.
		HashMap<Integer, String> uservotes = new HashMap<Integer,String>();
		Object uservotesO = session.getAttribute("uservotes");
		if(uservotes != null && (uservotesO instanceof HashMap<?, ?>)){
			uservotes = (HashMap<Integer,String>) uservotesO;
		}		
		session.setAttribute("uservotes", uservotes);
		
		//get the assertion list
		List<assertionNode> assertions = AssertionsXML.getAssertionList(assertionXML);
		for(Iterator it = assertions.iterator(); it.hasNext();){
		//print out any assertions that have already been made, and while printing them
		//out, process any votes that have been submitted for each assertion.
			assertionNode thisnode = (assertionNode) it.next();
			int ID = thisnode.getID();
			String vote = request.getParameter("vote"+ID);
			String delete = request.getParameter("delete"+ID);
			String thisuser = thisnode.getUsername();
			
			if(vote != null){
				thisnode.castVote(vote);
				uservotes.put(ID, vote);
				//AssertionsXML.castVote("/data/apps-swe432/swe432/WEB-INF/data/pschatzAssertions.xml",ID,vote);
				//AssertionsXML.castVote("/Applications/apache-tomcat-7.0.54/webapps/experiment/WEB-INF/data/KSVoting/pschatzAssertions.xml",ID,vote);
				AssertionsXML.castVote("/var/www/CS/webapps/uprapham/WEB-INF/data/KSVoting/pschatzAssertions.xml",ID,vote);
			}
			
			
			if(delete != null){
				it.remove();
				//AssertionsXML.deleteAssertion("/data/apps-swe432/swe432/WEB-INF/data/pschatzAssertions.xml", ID);
				//AssertionsXML.deleteAssertion("/Applications/apache-tomcat-7.0.54/webapps/experiment/WEB-INF/data/KSVoting/pschatzAssertions.xml", ID);
				AssertionsXML.deleteAssertion("/var/www/CS/webapps/uprapham/WEB-INF/data/KSVoting/pschatzAssertions.xml", ID);
			}
		}
		
		Collections.sort(assertions);
		Collections.reverse(assertions);
 		session.setAttribute("assertionList", assertions); 
		
		session.setAttribute("loginvalid", "");
		session.setAttribute("newusererror","");
			
		// if the user clicks the log off button then remove the username and uservote from the session object 
		String logoff = request.getParameter("logoff");
		if(logoff != null){	
			session.removeAttribute("username");
			session.removeAttribute("uservotes");
		}

		String usernameLogin = request.getParameter("usernameLogin");
		if(usernameLogin != null){
			String password = request.getParameter("userpw");
			boolean pwvalid = CheckXMLUsers.validateUser(usernameLogin, password);
			//boolean pwvalid = CheckXMLUsers.userNameTaken(usernameLogin);
			if(pwvalid)
				session.setAttribute("username", usernameLogin);
			else {
				session.setAttribute("loginvalid","Username or password not found!");
				dispatcher = request.getRequestDispatcher(loginPage);
				dispatcher.forward(request, response);
				return;
			}
		} 
		
		//code for new user:
		if(request.getParameter("newuser") != null){
			dispatcher = request.getRequestDispatcher(newUserPage);
			dispatcher.forward(request, response);
			return;
		}
		
		String newname = request.getParameter("newname");
		if(newname!= null){
			if(newname == ""){
				session.setAttribute("newusererror","Please enter a valid username, and make sure JavaScript is enabled.");
				dispatcher = request.getRequestDispatcher(newUserPage);
				dispatcher.forward(request, response);
				return;

			} else
			if(CheckXMLUsers.userNameTaken(newname)){
				session.setAttribute("newusererror","Username already exists.  Please try a different name.");
				dispatcher = request.getRequestDispatcher(newUserPage);
				dispatcher.forward(request, response);
				return;
				
			} else {
				CheckXMLUsers.addUser(newname, request.getParameter("signPW"));
				session.setAttribute("username", newname);
			}
		}
		
		String username = (String) session.getAttribute("username");
		
		// checks if the user is logged in and sets the signedin boolean to true 
		if(username != null){ 
	  		signedin = true;
	  	} else {
			dispatcher = request.getRequestDispatcher(loginPage);
			dispatcher.forward(request, response);
			return;
		}
		
		

		
		Integer assertID = AssertionsXML.getAssertID(assertionXML);
		
		// checks if new assestions are made and updates the page 
		String tempassertion = request.getParameter("assertion");
		if(tempassertion != null) { // if a new assertion has been made, create a new assertionNode 
			String tempdefense = request.getParameter("defense");//and add the assertion to the list.
			if(tempdefense == null) 
				tempdefense = ""; // since the Javascript prevents empty defense fields, we should never get here. 
			assertionNode newnode = new assertionNode(assertID,tempassertion,tempdefense, username); 
			synchronized(this){
				AssertionsXML.addAssertion(assertionXML, newnode);
				assertID++;
				AssertionsXML.setAssertID(assertionXML, assertID);
			}
			assertions.add(newnode);
			session.setAttribute("assertionList", assertions);
		}
		if(signedin){
			dispatcher = request.getRequestDispatcher(assertionPage);
			dispatcher.forward(request, response);
			return;
		}
	
	}



}
