/**
 * SWE 432 - Fall 2012 
 * Maria Kohistani and Peter Schatz
 */

package KSVoting;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

/**
 *
 * @author Marjan
 */
public class CheckXMLUsers {
	  //private static final String xmlFile = "/data/apps-swe432/swe432/WEB-INF/data/mkohist2UserXML.xml";
	//private static final String xmlFile = "/Applications/apache-tomcat-7.0.54/webapps/experiment/WEB-INF/data/KSVoting/mkohist2UserXML.xml";
	private static final String xmlFile = "/var/www/CS/webapps/uprapham/WEB-INF/data/KSVoting/mkohist2UserXML.xml";
	
/*    public static void main(String[] args) throws IOException, SAXException {
        // TODO code application logic here
        String name = "Maria";
        String pw = "Maria123";
        System.out.println("User name " + name + " is: " + validateUser(name, pw));
        
        String name1 = "Bob";
        String pw1 = "Bobby123";
        addUser(name1, pw1);
        System.out.println("User added to XML file");
        
        String name2 = "Peter";
        System.out.println("User name " + name2 + " is: " + checkUserName(name2));
        
    } */

    // Check existing users in the XML file
    public static boolean validateUser(String name, String password) {
        String userName1;
        String userPW;
        try {
            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(xmlFile);

            doc.getDocumentElement().normalize();

            NodeList listOfPersons = doc.getElementsByTagName("User");
            // int totalPersons = listOfPersons.getLength();

            for (int s = 0; s < listOfPersons.getLength(); s++) {

                Node firstPersonNode = listOfPersons.item(s);
                if (firstPersonNode.getNodeType() == Node.ELEMENT_NODE) {

                    Element firstUserElement = (Element) firstPersonNode;

                    //-------
                    NodeList userName = firstUserElement.getElementsByTagName("Name");
                    Element nameElement = (Element) userName.item(0);

                    NodeList textFNList = nameElement.getChildNodes();
                    userName1 = ((Node) textFNList.item(0)).getNodeValue();

                    //-------
                    NodeList userPassword = firstUserElement.getElementsByTagName("Password");
                    Element passwordElement = (Element) userPassword.item(0);

                    NodeList textPWList = passwordElement.getChildNodes();
                    userPW = ((Node) textPWList.item(0)).getNodeValue();

                    //check if user name and password match
                    if (userName1.equals(name) && userPW.equals(password)) {
                        return true;
                    }
                }//end of if clause
            }//end of for loop with s var			

            return false;

        } catch (SAXParseException err) {
            System.out.println("** Parsing error" + ", line "
                    + err.getLineNumber() + ", uri " + err.getSystemId());
            System.out.println(" " + err.getMessage());

        } catch (SAXException e) {
            Exception x = e.getException();
            ((x == null) ? e : x).printStackTrace();

        } catch (Throwable t) {
            t.printStackTrace();
        }
        return false;
    }

    // Add a new user to the XML file
    public static void addUser(String name, String password) {
        try {
            Element rootElement;
            DocumentBuilderFactory builderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = builderFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(xmlFile);

            rootElement = doc.getDocumentElement();
//            String sr = rootElement.getNodeName();
               

            //staff elements
            Element staff = doc.createElement("User");


            //firstname elements
            Element userName = doc.createElement("Name");
            userName.appendChild(doc.createTextNode(name));
            staff.appendChild(userName);

            //lastname elements
            Element userPW = doc.createElement("Password");
            userPW.appendChild(doc.createTextNode(password));
            staff.appendChild(userPW);
            
            rootElement.appendChild(staff);

            //write the content into xml file
			DOMSource source = new DOMSource(doc);

			TransformerFactory transformerFactory = TransformerFactory.newInstance();
			Transformer transformer = transformerFactory.newTransformer();
			StreamResult result = new StreamResult(xmlFile);
			transformer.transform(source, result);

        } catch (SAXParseException err) {
			System.out.println ("** Parsing error" + ", line " 
					+ err.getLineNumber () + ", uri " + err.getSystemId ());
			System.out.println(" " + err.getMessage ());

		}catch (SAXException e) {
			Exception x = e.getException ();
			((x == null) ? e : x).printStackTrace ();

		}catch (Throwable t) {
			t.printStackTrace ();
		}
    }
    
    // Check if username is taken- if username is taken return true
    public static boolean userNameTaken(String name){
        String userName1;

        try {
            DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
            Document doc = docBuilder.parse(xmlFile);

            //Element root = doc.getDocumentElement();
            
            /*NodeList username = root.getElementsByTagName(name);
            
            return(username.getLength() == 0); */

            NodeList listOfPersons = doc.getElementsByTagName("User");
            // int totalPersons = listOfPersons.getLength();

            for (int s = 0; s < listOfPersons.getLength(); s++) {

                Node firstPersonNode = listOfPersons.item(s);
                if (firstPersonNode.getNodeType() == Node.ELEMENT_NODE) {

                    Element firstUserElement = (Element) firstPersonNode;

                    //-------
                    NodeList userName = firstUserElement.getElementsByTagName("Name");
                    Element nameElement = (Element) userName.item(0);

                    NodeList textFNList = nameElement.getChildNodes();
                    userName1 = ((Node) textFNList.item(0)).getNodeValue();

                    //check if user name and password match
                    if (userName1.equals(name)) {
                        return true;
                    }
                }//end of if clause
            }//end of for loop with s var			
            
            

        } catch (SAXParseException err) {
            System.out.println("** Parsing error" + ", line "
                    + err.getLineNumber() + ", uri " + err.getSystemId());
            System.out.println(" " + err.getMessage());

        } catch (SAXException e) {
            Exception x = e.getException();
            ((x == null) ? e : x).printStackTrace();

        } catch (Throwable t) {
            t.printStackTrace();
        }
        return false;
    }
}
