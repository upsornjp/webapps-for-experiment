/**
 * SWE 432 - Fall 2012 
 * Maria Kohistani and Peter Schatz
 */

package KSVoting;

import java.util.LinkedList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;


public class AssertionsXML {
		
		private static String getTextValue(Element doc, String tag) {
		    String value = null;
		    NodeList nl;
		    nl = doc.getElementsByTagName(tag);
		    if (nl.getLength() > 0 && nl.item(0).hasChildNodes()) {
		        value = nl.item(0).getFirstChild().getNodeValue();
		    }
		    return value;
		}
		
		private static int getIntValue(Element ele, String tagName) {
			//in production application you would catch the exception
			return Integer.parseInt(getTextValue(ele,tagName));
		}
		
		public static List<assertionNode> getAssertionList(String xmlFile){
		    List<assertionNode> assertions = new LinkedList<assertionNode>();
		    // Make an  instance of the DocumentBuilderFactory
		    DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		    try {

		    	DocumentBuilder docBuilder = dbf.newDocumentBuilder();
	            Document doc = docBuilder.parse(xmlFile);

	/*            // normalize text representation
	            doc.getDocumentElement().normalize();
	            System.out.println ("Root element of the doc is " + 
	                 doc.getDocumentElement().getNodeName());*/


	            NodeList assertionNL = doc.getElementsByTagName("node");
	            int assertCount = assertionNL.getLength();

	            for(int i=0; i<assertCount; i++){


	                Node assertionN = assertionNL.item(i);
	                if(assertionN.getNodeType() == Node.ELEMENT_NODE){


	                    Element assertionElement = (Element)assertionN;

	                    int assertID = getIntValue(assertionElement, "id");
	                    
	                    String assertionStr = getTextValue(assertionElement, "assertion");
	                    
	                    String defenseStr = getTextValue(assertionElement, "defense");
	                    
	                    String username = getTextValue(assertionElement, "username");
	                    
	                    assertionNode assertion = new assertionNode(assertID, assertionStr, defenseStr, username);
	                    
	                    assertion.setConvinced(getIntValue(assertionElement, "convinced"));

	                    assertion.setUnsure(getIntValue(assertionElement, "unsure"));
	                    
	                    assertion.setDisagree(getIntValue(assertionElement, "disagree"));

	                    assertions.add(assertion);
	                    
	                }//end of if clause


	            }//end of for loop with s var


	        }catch (SAXParseException err) {
	        System.out.println ("** Parsing error" + ", line " 
	             + err.getLineNumber () + ", uri " + err.getSystemId ());
	        System.out.println(" " + err.getMessage ());

	        }catch (SAXException e) {
	        Exception x = e.getException ();
	        ((x == null) ? e : x).printStackTrace ();

	        }catch (Throwable t) {
	        t.printStackTrace ();
	        }
		    
		    return assertions;
		} 
				
		public static void addAssertion(String xmlFile, assertionNode assertion){
			String ID = Integer.toString(assertion.getID());
			String convinced = Integer.toString(assertion.getConvinced());
			String unsure = Integer.toString(assertion.getUnsure());
			String disagree = Integer.toString(assertion.getDisagree());		
			try{
				DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
				DocumentBuilder docBuilder = dbf.newDocumentBuilder();
				Document doc = docBuilder.parse(xmlFile);

				Element root = (Element) doc.getElementsByTagName("assertionlist").item(0);

				Element assertNode = doc.createElement("node");

				Element id = doc.createElement("id");
				id.appendChild(doc.createTextNode(ID));
				assertNode.appendChild(id);

				Element assertiontext = doc.createElement("assertion");
				assertiontext.appendChild(doc.createTextNode(assertion.getAssertion()));
				assertNode.appendChild(assertiontext);

				Element defense = doc.createElement("defense");
				defense.appendChild(doc.createTextNode(assertion.getDefense()));
				assertNode.appendChild(defense);

				Element username = doc.createElement("username");
				username.appendChild(doc.createTextNode(assertion.getUsername()));
				assertNode.appendChild(username);

				Element convincedEl = doc.createElement("convinced");
				convincedEl.appendChild(doc.createTextNode(convinced));
				assertNode.appendChild(convincedEl);

				Element unsureEl = doc.createElement("unsure");
				unsureEl.appendChild(doc.createTextNode(unsure));
				assertNode.appendChild(unsureEl);

				Element disagreeEl = doc.createElement("disagree");
				disagreeEl.appendChild(doc.createTextNode(disagree));
				assertNode.appendChild(disagreeEl);

				root.appendChild(assertNode);

				DOMSource source = new DOMSource(doc);

				TransformerFactory transformerFactory = TransformerFactory.newInstance();
				Transformer transformer = transformerFactory.newTransformer();
				StreamResult result = new StreamResult(xmlFile);
				transformer.transform(source, result);

			} catch (SAXParseException err) {
				System.out.println ("** Parsing error" + ", line " 
						+ err.getLineNumber () + ", uri " + err.getSystemId ());
				System.out.println(" " + err.getMessage ());

			}catch (SAXException e) {
				Exception x = e.getException ();
				((x == null) ? e : x).printStackTrace ();

			}catch (Throwable t) {
				t.printStackTrace ();
			}


		}
		
		public static void deleteAssertion(String xmlFile, int nodeID){
			String ID = Integer.toString(nodeID);
			try{
				DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
				Document doc = dbf.newDocumentBuilder().parse(xmlFile);
				
				Element root = (Element) doc.getElementsByTagName("assertionlist").item(0);
				
				NodeList nl = root.getElementsByTagName("node");
				
				for(int i=0; i<nl.getLength(); i++){
					Element targetID = (Element) nl.item(i);
					Node targetNode = targetID.getElementsByTagName("id").item(0).getFirstChild();
					if(getTextValue(targetID,"id").equals(ID)){
						root.removeChild(targetID);
						break;
					}
					
				}
				
				
				DOMSource source = new DOMSource(doc);

				TransformerFactory transformerFactory = TransformerFactory.newInstance();
				Transformer transformer = transformerFactory.newTransformer();
				StreamResult result = new StreamResult(xmlFile);
				transformer.transform(source, result);

				
			} catch (SAXParseException err) {
				System.out.println ("** Parsing error" + ", line " 
						+ err.getLineNumber () + ", uri " + err.getSystemId ());
				System.out.println(" " + err.getMessage ());

			}catch (SAXException e) {
				Exception x = e.getException ();
				((x == null) ? e : x).printStackTrace ();

			}catch (Throwable t) {
				t.printStackTrace ();
			}
		}

		
		public static void setAssertID(String xmlFile, int assertID){
			String nextID = Integer.toString(assertID);
			try{
				DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
				Document doc = dbf.newDocumentBuilder().parse(xmlFile);
				
				NodeList nodes = doc.getElementsByTagName("nextID");
				Node node = nodes.item(0);
				Node newNode = doc.createElement("nextID");// Create your new node here.
				newNode.appendChild(doc.createTextNode(nextID));
				Node parentnode = node.getParentNode();
			    parentnode.removeChild(node);
			    parentnode.appendChild(newNode);
				
				DOMSource source = new DOMSource(doc);

				TransformerFactory transformerFactory = TransformerFactory.newInstance();
				Transformer transformer = transformerFactory.newTransformer();
				StreamResult result = new StreamResult(xmlFile);
				transformer.transform(source, result);

				
			} catch (SAXParseException err) {
				System.out.println ("** Parsing error" + ", line " 
						+ err.getLineNumber () + ", uri " + err.getSystemId ());
				System.out.println(" " + err.getMessage ());

			}catch (SAXException e) {
				Exception x = e.getException ();
				((x == null) ? e : x).printStackTrace ();

			}catch (Throwable t) {
				t.printStackTrace ();
			}
		}
		
		public static int getAssertID(String xmlFile){
			int assertID = 0;
			try{
				DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
				Document doc = dbf.newDocumentBuilder().parse(xmlFile);
				
				Element root = doc.getDocumentElement();
				assertID = getIntValue(root,"nextID");
				
			} catch (SAXParseException err) {
				System.out.println ("** Parsing error" + ", line " 
						+ err.getLineNumber () + ", uri " + err.getSystemId ());
				System.out.println(" " + err.getMessage ());

			}catch (SAXException e) {
				Exception x = e.getException ();
				((x == null) ? e : x).printStackTrace ();

			}catch (Throwable t) {
				t.printStackTrace ();
			}
			return assertID;
		}
		
		public static void castVote(String xmlFile, int voteID, String vote){
				String ID = Integer.toString(voteID);
				try{
					DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
					Document doc = dbf.newDocumentBuilder().parse(xmlFile);
					
					Element root = (Element) doc.getElementsByTagName("assertionlist").item(0);
					
					NodeList nl = root.getElementsByTagName("node");
					
					for(int i=0; i<nl.getLength(); i++){
						Element targetID = (Element) nl.item(i);
						Element targetNode = (Element) targetID.getElementsByTagName("id").item(0);
						if(getTextValue(targetID, "id").equals(ID)){
							Element voteElement = (Element) targetID.getElementsByTagName(vote).item(0);
							int votecount = getIntValue(targetID,vote) + 1;
							voteElement.setTextContent(Integer.toString(votecount));
							break;
						}
						
					}
					
					
					DOMSource source = new DOMSource(doc);

					TransformerFactory transformerFactory = TransformerFactory.newInstance();
					Transformer transformer = transformerFactory.newTransformer();
					StreamResult result = new StreamResult(xmlFile);
					transformer.transform(source, result);

					
				} catch (SAXParseException err) {
					System.out.println ("** Parsing error" + ", line " 
							+ err.getLineNumber () + ", uri " + err.getSystemId ());
					System.out.println(" " + err.getMessage ());

				}catch (SAXException e) {
					Exception x = e.getException ();
					((x == null) ? e : x).printStackTrace ();

				}catch (Throwable t) {
					t.printStackTrace ();
				}
			
			
		}
		
/*		public static void main(String [ ] args){
			assertionNode testNode = new assertionNode(1,"testa","testd","blah");
			addAssertion("assertions.xml",testNode);
		}*/
	
}