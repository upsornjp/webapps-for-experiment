/**
 * SWE 432 - Fall 2012 
 * Maria Kohistani and Peter Schatz
 */

package KSVoting;

public class assertionNode implements Comparable<assertionNode>{
	//inner class for storing an individual assertion and any voting associated with it.
	private String assertion, defense, username;
	private int convinced, unsure, disagree, assertionID;

	public assertionNode(Integer ID, String assertion, String defense, String username){
		assertionID = ID;
		this.assertion = assertion;
		this.defense = defense;
		this.username = username;
		convinced = unsure = disagree = 0;
	}

	public int compareTo(assertionNode node){
		return this.convinced - node.convinced;
	}
	
	public void castVote (String vote){
		if(vote.contains("convinced"))  convinced++; 
		else if (vote.contains("not sure"))  unsure++; 
		else if (vote.contains("disagree"))  disagree++;
	}

	public int getConvinced(){
		return convinced;
	}
	
	public void setConvinced(int conv){
		convinced = conv;
	}

	public int getUnsure(){
		return unsure;
	}

	public void setUnsure(int unsure){
		this.unsure = unsure;
	}

	public int getDisagree(){
		return disagree;
	}
	
	public void setDisagree(int dis){
		disagree = disagree;
	}

	public String getAssertion(){
		return assertion;
	}

	public String getDefense(){
		return defense;
	}

	public int getID(){
		return assertionID;
	}
	
	public String getUsername(){
		return username;
	}

}